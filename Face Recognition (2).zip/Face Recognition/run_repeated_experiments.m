function run_repeated_experiments
% MATLAB R2025b. 保存本文件后运行 run_repeated_experiments。
% 选择原项目；固定输出目录支持重新运行续跑。修改协议时请另建输出目录。
% 5次分层随机留出，不是5折交叉验证；各次测试集可能重叠。
% 每次网络从ImageNet重新开始。验证集选模型，测试集只评价。
% 固定种子不保证GPU逐位一致；波动包含划分与训练随机性。
clc;
project=uigetdir(pwd,'选择含 manifests 的 FaceProject_20260916_140101_801');
if isequal(project,0), return; end
names=["ORL","GeorgiaTech","ExtendedYaleB"];
methods=["HOG_SVM","LBP_SVM","AlexNet","ResNet50","MobileNetV2"];
seeds=20261001:20261005; % 预先固定，不能按测试结果挑选种子
protocol="repeated_holdout_v1";
out=fullfile(project,'experiments','RepeatedHoldout_v1');
if ~isfolder(out), mkdir(out); end
fprintf('输出及续跑目录：%s\n',out);
base=cell(3,1);
for d=1:3
    T=readCSV(fullfile(project,'manifests',names(d)+"_split.csv"));
    assert(all(ismember({'File','Label','Split'},T.Properties.VariableNames)),'缺少File/Label/Split');
    T.File=string(T.File); T.Label=string(T.Label); T.Split=string(T.Split);
    assert(all(isfile(T.File)),'图片路径失效：请保留原有FaceProject目录');
    assert(numel(unique(T.File))==height(T),'重复路径');
    assert(all(ismember(T.Split,["train","validation","test"])), '划分字段异常');
    base{d}=sortrows(T,{'Label','File'});
end
state=fullfile(out,'protocol.mat');
if isfile(state)
    old=load(state);
    assert(isequal(old.seeds,seeds)&&isequal(old.methods,methods)&& ...
        isequal(old.base,base)&&isequal(old.protocol,protocol), ...
        '协议或原清单改变，请使用新的输出目录，不能混合续跑。');
else
    save(state,'seeds','names','methods','base','protocol','project');
end
assert(gpuDeviceCount('available')>0,'需要可用GPU');
diary(fullfile(out,'run_log.txt')); guard=onCleanup(@() diary('off'));
fid=fopen(fullfile(out,'README.txt'),'w');
fprintf(fid,['Five stratified random holdouts, NOT five-fold cross validation.\n' ...
    'Preserve original per-identity train/validation/test counts. Shared splits across methods.\n' ...
    'Five predeclared seeds: 20261001 to 20261005. Old baseline is separate.\n' ...
    'SVM: linear one-vs-one, training-only standardization, validation-only C selection.\n' ...
    'CNN: fresh ImageNet initialization each run, 20 epochs, SGDM, LR 1e-4, batch 16.\n' ...
    'Best validation loss; no augmentation. Test images never used to select models.\n' ...
    'CSV scores are fractions; plots show percentages. SD uses N-1 denominator.\n' ...
    'Error bars are SD, NOT confidence intervals. Trials have overlapping test samples.\n' ...
    'Variation includes split and training randomness. GPU is not bitwise deterministic.\n' ...
    'Each task saves a completion MAT only after evaluation. Rerun skips completed tasks.\n' ...
    'Interrupted incomplete tasks restart. Baseline files are not modified.\n' ...
    'Models and per-image predictions are retained; allow several GB of free disk space.\n']); fclose(fid);
allResults=table(); runners={@repeatHOG,@repeatLBP,@repeatAlex,@repeatRes,@repeatMobile};
for r=1:numel(seeds)
    seed=seeds(r);
    trial=fullfile(out,sprintf('seed_%d',seed));
    if ~isfolder(trial), mkdir(trial); end
    for d=1:3
        T=base{d}; rng(seed,'twister');
        ids=unique(T.Label);
        for j=1:numel(ids)
            rows=find(T.Label==ids(j));
            ntr=sum(T.Split(rows)=="train"); nv=sum(T.Split(rows)=="validation");
            nt=sum(T.Split(rows)=="test");
            assert(min([ntr nv nt])>0,'每个身份必须在三个子集中都有样本');
            rows=rows(randperm(numel(rows)));
            T.Split(rows(1:ntr))="train";
            T.Split(rows(ntr+1:ntr+nv))="validation";
            T.Split(rows(ntr+nv+1:end))="test";
        end
        splitFile=fullfile(trial,names(d)+"_split.csv");
        if isfile(splitFile)
            S=readCSV(splitFile);
            assert(isequal(string(S.File),T.File)&&isequal(string(S.Label),T.Label)&& ...
                isequal(string(S.Split),T.Split),'续跑划分不一致');
        else
            writetable(T,splitFile);
        end
        for m=1:numel(methods)
            dest=fullfile(trial,names(d),methods(m));
            if ~isfolder(dest), mkdir(dest); end
            done=fullfile(dest,'completed.mat');
            fprintf('\n===== 第%d/5次 | %s | %s =====\n',r,names(d),methods(m));
            if isfile(done)
                Q=load(done,'row','savedT','savedSeed');
                assert(isequal(Q.savedT,T)&&Q.savedSeed==seed,'完成记录不匹配');
                row=Q.row; fprintf('已完成，跳过训练。\n');
            else
                try
                    raw=runners{m}(T,dest,seed,names(d));
                    row=raw(:,{'Dataset','Method','Train','Validation','Test', ...
                        'ValidationAccuracy','TestAccuracy','MacroF1'});
                    row.Seed=seed; row.Repeat=r;
                    P=readCSV(fullfile(dest,'test_predictions.csv'));
                    assert(isequal(string(P.File),T.File(T.Split=="test")), '预测样本错位');
                    actual=mean(string(P.Label)==string(P.Prediction));
                    assert(abs(actual-row.TestAccuracy)<1e-10,'预测与指标不一致');
                    C=confusionmat(categorical(P.Label),categorical(P.Prediction), ...
                        'Order',categorical(unique(T.Label)));
                    f1=2*diag(C)./max(sum(C,1)'+sum(C,2),1);
                    assert(abs(mean(f1)-row.MacroF1)<1e-10,'宏F1与逐图预测不一致');
                    savedT=T; savedSeed=seed;
                    save(fullfile(dest,'completion_pending.mat'),'row','savedT','savedSeed');
                    movefile(fullfile(dest,'completion_pending.mat'),done);
                catch ME
                    fid=fopen(fullfile(dest,'error.txt'),'w');
                    fprintf(fid,'%s',getReport(ME,'extended','hyperlinks','off')); fclose(fid);
                    fprintf('本组未完成。修复后重新运行本文件，选择同一项目即可续跑。\n');
                    rethrow(ME);
                end
            end
            allResults=[allResults;row]; %#ok<AGROW>
            writetable(allResults,fullfile(out,'progress_results.csv'));
            fprintf('测试准确率 %.2f%%，宏F1 %.4f；进度 %d/75\n', ...
                100*row.TestAccuracy,row.MacroF1,height(allResults));
        end
    end
end
assert(height(allResults)==75,'实验不完整');
writetable(allResults,fullfile(out,'all_results.csv'));
S=table();
for d=1:3
    for m=1:5
        A=allResults(allResults.Dataset==names(d)&allResults.Method==methods(m),:);
        assert(height(A)==5&&numel(unique(A.Seed))==5,'重复次数不匹配');
        z=table(names(d),methods(m),height(A),mean(A.TestAccuracy),std(A.TestAccuracy), ...
            mean(A.MacroF1),std(A.MacroF1),'VariableNames', ...
            {'Dataset','Method','Repeats','AccuracyMean','AccuracySD','MacroF1Mean','MacroF1SD'});
        S=[S;z]; %#ok<AGROW>
    end
end
writetable(S,fullfile(out,'mean_std_summary.csv'));
plotRepeats(allResults,S,names,methods,out);
disp(S); fprintf('\n75组完成。均值、标准差和9张图已保存：\n%s\n',out);
end

function T=readCSV(file)
T=readtable(file,'FileType','text','Delimiter',',','Encoding','UTF-8', ...
    'ReadVariableNames',true,'NumHeaderLines',0,'VariableNamingRule','preserve','TextType','string');
end

function plotRepeats(A,S,names,methods,out)
colors=[0.12 0.47 0.71;1 0.50 0.05;0.17 0.63 0.17;0.84 0.15 0.16;0.58 0.40 0.74];
for d=1:3
    B=S(S.Dataset==names(d),:);
    for metric=1:2
        if metric==1
            mu=B.AccuracyMean; sd=B.AccuracySD; label="Accuracy";
            field='TestAccuracy';
        else
            mu=B.MacroF1Mean; sd=B.MacroF1SD; label="Macro-F1";
            field='MacroF1';
        end
        fig=figure('Visible','off','Color','w','Position',[100 100 1100 700]);
        b=bar(1:5,100*mu,'FaceColor','flat'); b.CData=colors; hold on;
        errorbar(1:5,100*mu,100*sd,'k.','LineWidth',1.5,'CapSize',14);
        for m=1:5
            R=sortrows(A(A.Dataset==names(d)&A.Method==methods(m),:),'Repeat');
            scatter(m+linspace(-.12,.12,5)',100*R.(field),35,'k','filled');
        end
        xticks(1:5); xticklabels(methods); set(gca,'TickLabelInterpreter','none');
        ylim([0 105]); ylabel(label+" (%)"); grid on;
        title(names(d)+" | mean +/- SD; dots = 5 holdouts");
        writePlot(fig,out,names(d)+"_"+replace(label,'-','')+"_mean_sd");
    end
    fig=figure('Visible','off','Color','w','Position',[100 100 1100 700]); hold on;
    for m=1:5
        R=sortrows(A(A.Dataset==names(d)&A.Method==methods(m),:),'Repeat');
        boxchart(repmat(m,5,1),100*R.TestAccuracy,'BoxFaceColor',colors(m,:));
        scatter(m+linspace(-.12,.12,5)',100*R.TestAccuracy,45,colors(m,:),'filled');
    end
    xticks(1:5); xticklabels(methods); set(gca,'TickLabelInterpreter','none');
    ylabel('Test accuracy (%)'); ylim([0 105]); grid on;
    title(names(d)+" | 5 holdouts (all points shown; small sample)");
    writePlot(fig,out,names(d)+"_accuracy_boxplot");
end
end
function writePlot(fig,out,name)
guard=onCleanup(@() close(fig));
savefig(fig,fullfile(out,name+".fig"));
exportgraphics(fig,fullfile(out,name+".png"),'Resolution',300);
end

function row=repeatHOG(T,dest,seed,dataset)
config=struct('ImageSize',[112 96],'CellSize',[8 8],...
    'CValues',[0.01 0.1 1 10],'Seed',20260916,...
    'TSNEPeople',10,'PredictionRepeats',3);
config.Seed=seed;
    writetable(T,fullfile(dest,'split_used.csv'));
    rng(config.Seed,'twister');
    n=height(T); train=T.Split=="train"; val=T.Split=="validation"; test=T.Split=="test";
    Y=categorical(T.Label); order=categorical(categories(Y));
    first=readHogImage(T.File(1),config.ImageSize);
    width=numel(extractHOGFeatures(first,'CellSize',config.CellSize));
    X=zeros(n,width,'single'); perImageSeconds=zeros(n,1);
    for i=1:n
        timer=tic;
        X(i,:)=extractHOGFeatures(readHogImage(T.File(i),config.ImageSize),'CellSize',config.CellSize);
        perImageSeconds(i)=toc(timer);
        if mod(i,200)==0 || i==n, fprintf('特征提取 %d/%d\n',i,n); end
    end
    values=config.CValues; acc=zeros(numel(values),1); fitSeconds=acc;
    valPredictions=strings(sum(val),numel(values)); best=-Inf; model=[]; selectedC=NaN;
    tuningTimer=tic;
    for k=1:numel(values)
        learner=templateSVM('KernelFunction','linear','Standardize',true,'BoxConstraint',values(k));
        timer=tic;
        candidate=fitcecoc(X(train,:),Y(train),'Learners',learner,'Coding','onevsone');
        fitSeconds(k)=toc(timer);
        pred=predict(candidate,X(val,:)); valPredictions(:,k)=string(pred);
        acc(k)=mean(pred==Y(val));
        fprintf('C=%g，验证准确率 %.2f%%\n',values(k),100*acc(k));
        if acc(k)>best
            best=acc(k); model=candidate; selectedC=values(k); selectedTime=fitSeconds(k);
        end
    end
    tuningSeconds=toc(tuningTimer);
    predictions=predict(model,X(test,:)); % 首次预测与计时预热
    batchTimes=zeros(config.PredictionRepeats,1);
    for k=1:config.PredictionRepeats
        timer=tic; predict(model,X(test,:)); batchTimes(k)=toc(timer);
    end
    truth=Y(test); C=confusionmat(truth,predictions,'Order',order);
    tp=diag(C); precision=tp./max(sum(C,1)',1); recall=tp./max(sum(C,2),1);
    f1=2*precision.*recall./max(precision+recall,eps);
    accuracy=mean(truth==predictions); macroF1=mean(f1);
    predictionMs=1000*median(batchTimes)/sum(test);
    row=table(dataset,"HOG_SVM",sum(train),sum(val),sum(test),selectedC,...
        best,accuracy,macroF1,selectedTime,tuningSeconds,sum(perImageSeconds),...
        1000*mean(perImageSeconds(test)),predictionMs,...
        'VariableNames',{'Dataset','Method','Train','Validation','Test','SelectedC',...
        'ValidationAccuracy','TestAccuracy','MacroF1','TrainSeconds','TuningSeconds',...
        'AllImagesFeatureSeconds','TestReadAndHOGMsPerImage','ClassifierMsPerImage'});
    writetable(table(values(:),acc,fitSeconds,'VariableNames',{'C','ValidationAccuracy','FitSeconds'}),fullfile(dest,'parameter_results.csv'));
    V=T(val,:);
    for k=1:numel(values), V.(sprintf('Prediction_C_%d',k))=valPredictions(:,k); end
    writetable(V,fullfile(dest,'validation_predictions.csv'));
    P=T(test,:); P.Prediction=string(predictions); P.Correct=truth==predictions;
    writetable(P,fullfile(dest,'test_predictions.csv'));
    writetable(table(string(order),precision,recall,f1,sum(C,2),...
        'VariableNames',{'Identity','Precision','Recall','F1','Support'}),fullfile(dest,'class_metrics.csv'));
    writematrix(C,fullfile(dest,'confusion_counts.csv'));
    % 在绘图之前保存模型与特征，绘图失败也不会丢失训练结果。
    save(fullfile(dest,'experiment.mat'),'model','config','T','X','C','order',...
        'row','acc','valPredictions','perImageSeconds','batchTimes','-v7.3');
    fprintf('测试准确率 %.2f%%，宏平均F1 %.4f。\n',100*accuracy,macroF1);
function I=readHogImage(path,target)
    [I,map]=imread(path);
    if ~isempty(map), I=ind2rgb(I,map); end
    if size(I,3)==3, I=rgb2gray(I); end
    I=imresize(im2single(I),target);
end
end

function row=repeatLBP(T,dest,seed,dataset)
config=struct('ImageSize',[112 96],'CellSize',[8 8],'NumNeighbors',8,'Radius',1,...
    'CValues',[0.01 0.1 1 10],'Seed',20260916,...
    'TSNEPeople',10,'PredictionRepeats',3);
config.Seed=seed;
    writetable(T,fullfile(dest,'split_used.csv'));
    rng(config.Seed,'twister');
    n=height(T); train=T.Split=="train"; val=T.Split=="validation"; test=T.Split=="test";
    Y=categorical(T.Label); order=categorical(categories(Y));
    first=readLbpImage(T.File(1),config.ImageSize);
    width=numel(getLBP(first,config));
    X=zeros(n,width,'single'); perImageSeconds=zeros(n,1);
    for i=1:n
        timer=tic;
        X(i,:)=getLBP(readLbpImage(T.File(i),config.ImageSize),config);
        perImageSeconds(i)=toc(timer);
        if mod(i,200)==0 || i==n, fprintf('特征提取 %d/%d\n',i,n); end
    end
    values=config.CValues; acc=zeros(numel(values),1); fitSeconds=acc;
    valPredictions=strings(sum(val),numel(values)); best=-Inf; model=[]; selectedC=NaN;
    tuningTimer=tic;
    for k=1:numel(values)
        learner=templateSVM('KernelFunction','linear','Standardize',true,'BoxConstraint',values(k));
        timer=tic;
        candidate=fitcecoc(X(train,:),Y(train),'Learners',learner,'Coding','onevsone');
        fitSeconds(k)=toc(timer);
        pred=predict(candidate,X(val,:)); valPredictions(:,k)=string(pred);
        acc(k)=mean(pred==Y(val));
        fprintf('C=%g，验证准确率 %.2f%%\n',values(k),100*acc(k));
        if acc(k)>best
            best=acc(k); model=candidate; selectedC=values(k); selectedTime=fitSeconds(k);
        end
    end
    tuningSeconds=toc(tuningTimer);
    predictions=predict(model,X(test,:)); % 首次预测与计时预热
    batchTimes=zeros(config.PredictionRepeats,1);
    for k=1:config.PredictionRepeats
        timer=tic; predict(model,X(test,:)); batchTimes(k)=toc(timer);
    end
    truth=Y(test); C=confusionmat(truth,predictions,'Order',order);
    tp=diag(C); precision=tp./max(sum(C,1)',1); recall=tp./max(sum(C,2),1);
    f1=2*precision.*recall./max(precision+recall,eps);
    accuracy=mean(truth==predictions); macroF1=mean(f1);
    predictionMs=1000*median(batchTimes)/sum(test);
    row=table(dataset,"LBP_SVM",sum(train),sum(val),sum(test),selectedC,...
        best,accuracy,macroF1,selectedTime,tuningSeconds,sum(perImageSeconds),...
        1000*mean(perImageSeconds(test)),predictionMs,...
        'VariableNames',{'Dataset','Method','Train','Validation','Test','SelectedC',...
        'ValidationAccuracy','TestAccuracy','MacroF1','TrainSeconds','TuningSeconds',...
        'AllImagesFeatureSeconds','TestReadAndLBPMsPerImage','ClassifierMsPerImage'});
    writetable(table(values(:),acc,fitSeconds,'VariableNames',{'C','ValidationAccuracy','FitSeconds'}),fullfile(dest,'parameter_results.csv'));
    V=T(val,:);
    for k=1:numel(values), V.(sprintf('Prediction_C_%d',k))=valPredictions(:,k); end
    writetable(V,fullfile(dest,'validation_predictions.csv'));
    P=T(test,:); P.Prediction=string(predictions); P.Correct=truth==predictions;
    writetable(P,fullfile(dest,'test_predictions.csv'));
    writetable(table(string(order),precision,recall,f1,sum(C,2),...
        'VariableNames',{'Identity','Precision','Recall','F1','Support'}),fullfile(dest,'class_metrics.csv'));
    writematrix(C,fullfile(dest,'confusion_counts.csv'));
    % 在绘图之前保存模型与特征，绘图失败也不会丢失训练结果。
    save(fullfile(dest,'experiment.mat'),'model','config','T','X','C','order',...
        'row','acc','valPredictions','perImageSeconds','batchTimes','-v7.3');
    fprintf('测试准确率 %.2f%%，宏平均F1 %.4f。\n',100*accuracy,macroF1);
function I=readLbpImage(path,target)
    [I,map]=imread(path);
    if ~isempty(map), I=ind2rgb(I,map); end
    if size(I,3)==3, I=rgb2gray(I); end
    I=imresize(im2single(I),target);
end

function features=getLBP(I,cfg)
    features=extractLBPFeatures(I,'CellSize',cfg.CellSize,...
        'NumNeighbors',cfg.NumNeighbors,'Radius',cfg.Radius,...
        'Upright',true,'Interpolation','Linear','Normalization','L2');
end
end

function row=repeatAlex(T,dest,seed,dataset)
cfg=struct('Seed',20260916,'BatchSize',16,'MaxEpochs',20,...
    'LearnRate',1e-4,'HeadFactor',10,'TSNEPeople',10,'PredictionRepeats',3,...
    'FeatureLayer','relu7','ActivationLayer','relu1','Augmentation','none');
cfg.Seed=seed;
gpu=gpuDevice;
    writetable(T,fullfile(dest,'split_used.csv'));
    rng(cfg.Seed,'twister'); gpurng(cfg.Seed);
    Y=categorical(T.Label); classNames=categories(Y); order=categorical(classNames);
    train=T.Split=="train"; val=T.Split=="validation"; test=T.Split=="test";
    net=imagePretrainedNetwork('alexnet','NumClasses',numel(classNames));
    inputSize=net.Layers(1).InputSize;
    % 自动定位分类头，不依赖分类层的固定名字。
    fc=find(arrayfun(@(L) isa(L,'nnet.cnn.layer.FullyConnectedLayer'),net.Layers));
    assert(~isempty(fc),'未找到全连接分类层');
    head=string(net.Layers(fc(end)).Name);
    net=setLearnRateFactor(net,head+"/Weights",cfg.HeadFactor);
    net=setLearnRateFactor(net,head+"/Bias",cfg.HeadFactor);
    assert(any(string({net.Layers.Name})==cfg.FeatureLayer),'特征层名称不匹配');
    dsTrain=makeDS(T(train,:),inputSize); dsVal=makeDS(T(val,:),inputSize);
    dsTest=makeDS(T(test,:),inputSize);
    frequency=max(1,floor(sum(train)/cfg.BatchSize));
    options=trainingOptions('sgdm','InitialLearnRate',cfg.LearnRate,...
        'Momentum',0.9,'L2Regularization',1e-4,...
        'MiniBatchSize',cfg.BatchSize,'MaxEpochs',cfg.MaxEpochs,...
        'Shuffle','every-epoch','ValidationData',dsVal,...
        'ValidationFrequency',frequency,'ValidationPatience',Inf,...
        'OutputNetwork','best-validation','ObjectiveMetricName','loss',...
        'Metrics','accuracy','ExecutionEnvironment','gpu',...
        'Verbose',true,'VerboseFrequency',frequency,'Plots','none');
    wait(gpu); timer=tic;
    [net,info]=trainnet(dsTrain,net,'crossentropy',options);
    wait(gpu); trainSeconds=toc(timer);
    % 训练结束立即保存，后续绘图失败无需重训。
    save(fullfile(dest,'trained_model.mat'),'net','info','cfg','classNames','inputSize','T','trainSeconds','-v7.3');
    writetable(info.TrainingHistory,fullfile(dest,'training_history.csv'));
    writetable(info.ValidationHistory,fullfile(dest,'validation_history.csv'));
    valScores=predictScores(net,dsVal,cfg);
    scores=predictScores(net,dsTest,cfg); % 预热
    times=zeros(cfg.PredictionRepeats,1);
    for k=1:cfg.PredictionRepeats
        wait(gpu); timer=tic; predictScores(net,dsTest,cfg); wait(gpu); times(k)=toc(timer);
    end
    [~,index]=max(scores,[],2); predictions=categorical(string(classNames(index)));
    [~,index]=max(valScores,[],2); valPred=categorical(string(classNames(index)));
    truth=Y(test); C=confusionmat(truth,predictions,'Order',order);
    tp=diag(C); precision=tp./max(sum(C,1)',1); recall=tp./max(sum(C,2),1);
    f1=2*precision.*recall./max(precision+recall,eps);
    accuracy=mean(truth==predictions); macroF1=mean(f1);
    row=table(dataset,"AlexNet",sum(train),sum(val),sum(test),...
        mean(valPred==Y(val)),accuracy,macroF1,trainSeconds,...
        1000*median(times)/sum(test),info.OutputNetworkIteration,...
        'VariableNames',{'Dataset','Method','Train','Validation','Test',...
        'ValidationAccuracy','TestAccuracy','MacroF1','TrainSeconds',...
        'GPUReadResizeForwardMsPerImage','SelectedIteration'});
    P=T(test,:); P.Prediction=string(predictions); P.Correct=truth==predictions;
    P.MaxSoftmaxScore=max(scores,[],2); % 未校准分数，不用于陌生人拒识
    writetable(P,fullfile(dest,'test_predictions.csv'));
    writetable(table(string(order),precision,recall,f1,sum(C,2),...
        'VariableNames',{'Identity','Precision','Recall','F1','Support'}),fullfile(dest,'class_metrics.csv'));
    writematrix(C,fullfile(dest,'confusion_counts.csv'));
    save(fullfile(dest,'evaluation.mat'),'row','C','order','scores','valScores','P','times');
    fprintf('测试准确率 %.2f%%，宏平均F1 %.4f。\n',100*accuracy,macroF1);
function ds=makeDS(T,inputSize)
    imds=imageDatastore(cellstr(T.File),'ReadFcn',@readRGB);
    imds.Labels=categorical(T.Label);
    ds=augmentedImageDatastore(inputSize(1:2),imds);
end
function I=readRGB(path)
    [I,map]=imread(path);
    if ~isempty(map), I=im2uint8(ind2rgb(I,map)); else, I=im2uint8(I); end
    if size(I,3)==1, I=repmat(I,1,1,3); end
    assert(size(I,3)==3,'图像必须是灰度或RGB图像');
end
function scores=predictScores(net,ds,cfg)
    reset(ds);
    scores=minibatchpredict(net,ds,'MiniBatchSize',cfg.BatchSize,...
        'ExecutionEnvironment','gpu','OutputDataFormats','BC');
    if isa(scores,'dlarray'), scores=extractdata(scores); end
    scores=gather(scores);
end
end

function row=repeatRes(T,dest,seed,dataset)
cfg=struct('Seed',20260916,'BatchSize',16,'MaxEpochs',20,...
    'LearnRate',1e-4,'HeadFactor',10,'TSNEPeople',10,'PredictionRepeats',3,...
    'FeatureLayer','','ActivationLayer','','Augmentation','none');
cfg.Seed=seed;
gpu=gpuDevice;
    writetable(T,fullfile(dest,'split_used.csv'));
    rng(cfg.Seed,'twister'); gpurng(cfg.Seed);
    Y=categorical(T.Label); classNames=categories(Y); order=categorical(classNames);
    train=T.Split=="train"; val=T.Split=="validation"; test=T.Split=="test";
    net=imagePretrainedNetwork('resnet50','NumClasses',numel(classNames));
    inputSize=net.Layers(1).InputSize;
    % 自动定位分类头，不依赖分类层的固定名字。
    fc=find(arrayfun(@(L) isa(L,'nnet.cnn.layer.FullyConnectedLayer'),net.Layers));
    assert(~isempty(fc),'未找到全连接分类层');
    head=string(net.Layers(fc(end)).Name);
    net=setLearnRateFactor(net,head+"/Weights",cfg.HeadFactor);
    net=setLearnRateFactor(net,head+"/Bias",cfg.HeadFactor);
    % 从网络连接表定位分类头之前的池化特征，避免依赖固定层名。
    incoming=string(net.Connections.Source(string(net.Connections.Destination)==head));
    assert(numel(incoming)==1,'分类头输入连接不符合预期');
    cfg.FeatureLayer=char(extractBefore(incoming+"/","/"));
    reluIndex=find(arrayfun(@(L) isa(L,'nnet.cnn.layer.ReLULayer'),net.Layers),1);
    assert(~isempty(reluIndex),'未找到ReLU层');
    cfg.ActivationLayer=net.Layers(reluIndex).Name;
    fprintf('t-SNE特征层：%s；特征图层：%s\n',cfg.FeatureLayer,cfg.ActivationLayer);
    save(fullfile(dest,'config_resolved.mat'),'cfg','inputSize','head');
    dsTrain=makeDS(T(train,:),inputSize); dsVal=makeDS(T(val,:),inputSize);
    dsTest=makeDS(T(test,:),inputSize);
    frequency=max(1,floor(sum(train)/cfg.BatchSize));
    options=trainingOptions('sgdm','InitialLearnRate',cfg.LearnRate,...
        'Momentum',0.9,'L2Regularization',1e-4,...
        'MiniBatchSize',cfg.BatchSize,'MaxEpochs',cfg.MaxEpochs,...
        'Shuffle','every-epoch','ValidationData',dsVal,...
        'ValidationFrequency',frequency,'ValidationPatience',Inf,...
        'OutputNetwork','best-validation','ObjectiveMetricName','loss',...
        'Metrics','accuracy','ExecutionEnvironment','gpu',...
        'Verbose',true,'VerboseFrequency',frequency,'Plots','none');
    wait(gpu); timer=tic;
    [net,info]=trainnet(dsTrain,net,'crossentropy',options);
    wait(gpu); trainSeconds=toc(timer);
    % 训练结束立即保存，后续绘图失败无需重训。
    save(fullfile(dest,'trained_model.mat'),'net','info','cfg','classNames','inputSize','T','trainSeconds','-v7.3');
    writetable(info.TrainingHistory,fullfile(dest,'training_history.csv'));
    writetable(info.ValidationHistory,fullfile(dest,'validation_history.csv'));
    valScores=predictScores(net,dsVal,cfg);
    scores=predictScores(net,dsTest,cfg); % 预热
    times=zeros(cfg.PredictionRepeats,1);
    for k=1:cfg.PredictionRepeats
        wait(gpu); timer=tic; predictScores(net,dsTest,cfg); wait(gpu); times(k)=toc(timer);
    end
    [~,index]=max(scores,[],2); predictions=categorical(string(classNames(index)));
    [~,index]=max(valScores,[],2); valPred=categorical(string(classNames(index)));
    truth=Y(test); C=confusionmat(truth,predictions,'Order',order);
    tp=diag(C); precision=tp./max(sum(C,1)',1); recall=tp./max(sum(C,2),1);
    f1=2*precision.*recall./max(precision+recall,eps);
    accuracy=mean(truth==predictions); macroF1=mean(f1);
    row=table(dataset,"ResNet50",sum(train),sum(val),sum(test),...
        mean(valPred==Y(val)),accuracy,macroF1,trainSeconds,...
        1000*median(times)/sum(test),info.OutputNetworkIteration,...
        'VariableNames',{'Dataset','Method','Train','Validation','Test',...
        'ValidationAccuracy','TestAccuracy','MacroF1','TrainSeconds',...
        'GPUReadResizeForwardMsPerImage','SelectedIteration'});
    P=T(test,:); P.Prediction=string(predictions); P.Correct=truth==predictions;
    P.MaxSoftmaxScore=max(scores,[],2); % 未校准分数，不用于陌生人拒识
    writetable(P,fullfile(dest,'test_predictions.csv'));
    writetable(table(string(order),precision,recall,f1,sum(C,2),...
        'VariableNames',{'Identity','Precision','Recall','F1','Support'}),fullfile(dest,'class_metrics.csv'));
    writematrix(C,fullfile(dest,'confusion_counts.csv'));
    save(fullfile(dest,'evaluation.mat'),'row','C','order','scores','valScores','P','times');
    fprintf('测试准确率 %.2f%%，宏平均F1 %.4f。\n',100*accuracy,macroF1);
function ds=makeDS(T,inputSize)
    imds=imageDatastore(cellstr(T.File),'ReadFcn',@readRGB);
    imds.Labels=categorical(T.Label);
    ds=augmentedImageDatastore(inputSize(1:2),imds);
end
function I=readRGB(path)
    [I,map]=imread(path);
    if ~isempty(map), I=im2uint8(ind2rgb(I,map)); else, I=im2uint8(I); end
    if size(I,3)==1, I=repmat(I,1,1,3); end
    assert(size(I,3)==3,'图像必须是灰度或RGB图像');
end
function scores=predictScores(net,ds,cfg)
    reset(ds);
    scores=minibatchpredict(net,ds,'MiniBatchSize',cfg.BatchSize,...
        'ExecutionEnvironment','gpu','OutputDataFormats','BC');
    if isa(scores,'dlarray'), scores=extractdata(scores); end
    scores=gather(scores);
end
end

function row=repeatMobile(T,dest,seed,dataset)
cfg=struct('Seed',20260916,'BatchSize',16,'MaxEpochs',20,...
    'LearnRate',1e-4,'HeadFactor',10,'TSNEPeople',10,'PredictionRepeats',3,...
    'FeatureLayer','','ActivationLayer','','Augmentation','none');
cfg.Seed=seed;
gpu=gpuDevice;
    writetable(T,fullfile(dest,'split_used.csv'));
    rng(cfg.Seed,'twister'); gpurng(cfg.Seed);
    Y=categorical(T.Label); classNames=categories(Y); order=categorical(classNames);
    train=T.Split=="train"; val=T.Split=="validation"; test=T.Split=="test";
    net=imagePretrainedNetwork('mobilenetv2','NumClasses',numel(classNames));
    inputSize=net.Layers(1).InputSize;
    % 自动定位分类头，不依赖分类层的固定名字。
    fc=find(arrayfun(@(L) isa(L,'nnet.cnn.layer.FullyConnectedLayer'),net.Layers));
    assert(~isempty(fc),'未找到全连接分类层');
    head=string(net.Layers(fc(end)).Name);
    net=setLearnRateFactor(net,head+"/Weights",cfg.HeadFactor);
    net=setLearnRateFactor(net,head+"/Bias",cfg.HeadFactor);
    % 从网络连接表定位分类头之前的池化特征，避免依赖固定层名。
    incoming=string(net.Connections.Source(string(net.Connections.Destination)==head));
    assert(numel(incoming)==1,'分类头输入连接不符合预期');
    cfg.FeatureLayer=char(extractBefore(incoming+"/","/"));
    reluIndex=find(arrayfun(@(L) (isa(L,'nnet.cnn.layer.ReLULayer') || isa(L,'nnet.cnn.layer.ClippedReLULayer')),net.Layers),1);
    assert(~isempty(reluIndex),'未找到ReLU层');
    cfg.ActivationLayer=net.Layers(reluIndex).Name;
    fprintf('t-SNE特征层：%s；特征图层：%s\n',cfg.FeatureLayer,cfg.ActivationLayer);
    save(fullfile(dest,'config_resolved.mat'),'cfg','inputSize','head');
    dsTrain=makeDS(T(train,:),inputSize); dsVal=makeDS(T(val,:),inputSize);
    dsTest=makeDS(T(test,:),inputSize);
    frequency=max(1,floor(sum(train)/cfg.BatchSize));
    options=trainingOptions('sgdm','InitialLearnRate',cfg.LearnRate,...
        'Momentum',0.9,'L2Regularization',1e-4,...
        'MiniBatchSize',cfg.BatchSize,'MaxEpochs',cfg.MaxEpochs,...
        'Shuffle','every-epoch','ValidationData',dsVal,...
        'ValidationFrequency',frequency,'ValidationPatience',Inf,...
        'OutputNetwork','best-validation','ObjectiveMetricName','loss',...
        'Metrics','accuracy','ExecutionEnvironment','gpu',...
        'Verbose',true,'VerboseFrequency',frequency,'Plots','none');
    wait(gpu); timer=tic;
    [net,info]=trainnet(dsTrain,net,'crossentropy',options);
    wait(gpu); trainSeconds=toc(timer);
    % 训练结束立即保存，后续绘图失败无需重训。
    save(fullfile(dest,'trained_model.mat'),'net','info','cfg','classNames','inputSize','T','trainSeconds','-v7.3');
    writetable(info.TrainingHistory,fullfile(dest,'training_history.csv'));
    writetable(info.ValidationHistory,fullfile(dest,'validation_history.csv'));
    valScores=predictScores(net,dsVal,cfg);
    scores=predictScores(net,dsTest,cfg); % 预热
    times=zeros(cfg.PredictionRepeats,1);
    for k=1:cfg.PredictionRepeats
        wait(gpu); timer=tic; predictScores(net,dsTest,cfg); wait(gpu); times(k)=toc(timer);
    end
    [~,index]=max(scores,[],2); predictions=categorical(string(classNames(index)));
    [~,index]=max(valScores,[],2); valPred=categorical(string(classNames(index)));
    truth=Y(test); C=confusionmat(truth,predictions,'Order',order);
    tp=diag(C); precision=tp./max(sum(C,1)',1); recall=tp./max(sum(C,2),1);
    f1=2*precision.*recall./max(precision+recall,eps);
    accuracy=mean(truth==predictions); macroF1=mean(f1);
    row=table(dataset,"MobileNetV2",sum(train),sum(val),sum(test),...
        mean(valPred==Y(val)),accuracy,macroF1,trainSeconds,...
        1000*median(times)/sum(test),info.OutputNetworkIteration,...
        'VariableNames',{'Dataset','Method','Train','Validation','Test',...
        'ValidationAccuracy','TestAccuracy','MacroF1','TrainSeconds',...
        'GPUReadResizeForwardMsPerImage','SelectedIteration'});
    P=T(test,:); P.Prediction=string(predictions); P.Correct=truth==predictions;
    P.MaxSoftmaxScore=max(scores,[],2); % 未校准分数，不用于陌生人拒识
    writetable(P,fullfile(dest,'test_predictions.csv'));
    writetable(table(string(order),precision,recall,f1,sum(C,2),...
        'VariableNames',{'Identity','Precision','Recall','F1','Support'}),fullfile(dest,'class_metrics.csv'));
    writematrix(C,fullfile(dest,'confusion_counts.csv'));
    save(fullfile(dest,'evaluation.mat'),'row','C','order','scores','valScores','P','times');
    fprintf('测试准确率 %.2f%%，宏平均F1 %.4f。\n',100*accuracy,macroF1);
function ds=makeDS(T,inputSize)
    imds=imageDatastore(cellstr(T.File),'ReadFcn',@readRGB);
    imds.Labels=categorical(T.Label);
    ds=augmentedImageDatastore(inputSize(1:2),imds);
end
function I=readRGB(path)
    [I,map]=imread(path);
    if ~isempty(map), I=im2uint8(ind2rgb(I,map)); else, I=im2uint8(I); end
    if size(I,3)==1, I=repmat(I,1,1,3); end
    assert(size(I,3)==3,'图像必须是灰度或RGB图像');
end
function scores=predictScores(net,ds,cfg)
    reset(ds);
    scores=minibatchpredict(net,ds,'MiniBatchSize',cfg.BatchSize,...
        'ExecutionEnvironment','gpu','OutputDataFormats','BC');
    if isa(scores,'dlarray'), scores=extractdata(scores); end
    scores=gather(scores);
end
end
