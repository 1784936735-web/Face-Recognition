%% 人脸身份识别：第一阶段（MATLAB R2025b）
% 运行此脚本，选择包含三个ZIP的文件夹。
% 自动解压、检查数据、保存固定划分，并运行ORL的HOG+SVM基线。
% 本阶段不是五种方法的最终实验；后续方法应复用 manifests 中的划分。
% 修正版：支持GT文件名标签；复用检查通过的旧解压目录。
% 每次运行创建独立结果文件夹，不覆盖旧结果。
clear; clc;
seed = 20260916;
source = uigetdir(pwd,'选择包含 att_faces.zip、GTdb_crop.zip、CroppedYale.zip 的文件夹');
if isequal(source,0), disp('已取消。'); return; end
archives = ["att_faces.zip","GTdb_crop.zip","CroppedYale.zip"];
names = ["ORL","GeorgiaTech","ExtendedYaleB"];
listing = dir(source);
actualNames = string({listing.name});
archivePaths = strings(3,1);
for d = 1:3
    idx = find(strcmpi(actualNames,archives(d)),1);
    if isempty(idx)
        error('找不到 %s。请选择三个压缩包所在的文件夹。',archives(d));
    end
    archivePaths(d) = fullfile(source,actualNames(idx));
end
required = ["extractHOGFeatures","fitcecoc","templateSVM","imresize"];
for f = required
    assert(~isempty(which(char(f))),'缺少函数：%s',f);
end
project = fullfile(source,['FaceProject_' char(datetime('now','Format','yyyyMMdd_HHmmss_SSS'))]);
mkdir(project); mkdir(fullfile(project,'manifests')); mkdir(fullfile(project,'results'));
diary(fullfile(project,'run_log.txt'));
logCleanup = onCleanup(@() diary('off'));
fprintf('项目目录：%s\n随机种子：%d\n',project,seed);
summary = table(); datasets = cell(3,1);
for d = 1:3
    fprintf('\n===== %s：解压与检查 =====\n',names(d));
    destination = fullfile(project,'raw',names(d));
    % 旧版可能已成功解压，只是在解析标签时失败。
    reused = false;
    if d <= 2
        oldProjects = dir(fullfile(source,'FaceProject_*'));
        oldProjects = oldProjects([oldProjects.isdir]);
        [~,sequence] = sort([oldProjects.datenum],'descend');
        expectedImages = [400 750]; expectedPeople = [40 50];
        expectedPerPerson = [10 15];
        for q = sequence
            candidateRoot = fullfile(source,oldProjects(q).name,'raw',names(d));
            if ~isfolder(candidateRoot), continue; end
            [candidateTable,candidateExcluded] = inspectDataset(candidateRoot,names(d));
            candidateIds = unique(candidateTable.Label);
            candidateCounts = arrayfun(@(s) sum(candidateTable.Label==s),candidateIds);
            if height(candidateTable)==expectedImages(d) && ...
                    numel(candidateIds)==expectedPeople(d) && ...
                    all(candidateCounts==expectedPerPerson(d)) && isempty(candidateExcluded)
                destination = candidateRoot; reused = true;
                fprintf('复用已检查的解压目录：%s\n',destination);
                break;
            end
        end
    end
    if ~reused
        mkdir(destination);
        unzip(archivePaths(d),destination);
    end
    [manifest,excluded] = inspectDataset(destination,names(d));
    writetable(excluded,fullfile(project,'manifests',names(d)+"_excluded.csv"));
    if isempty(manifest), error('%s 没有找到可用且能识别人物编号的图像，请检查excluded.csv。',names(d)); end
    ids = unique(manifest.Label);
    counts = arrayfun(@(s) sum(manifest.Label == s),ids);
    fprintf('可用人数：%d，图片：%d，每人最少/最多：%d/%d\n',...
        numel(ids),height(manifest),min(counts),max(counts));
    writetable(excluded,fullfile(project,'manifests',names(d)+"_excluded.csv"));
    if any(counts < 5)
        writetable(manifest,fullfile(project,'manifests',names(d)+"_inventory.csv"));
        error('%s 有人物不足5张图片，请先检查inventory和excluded文件，不自动删除人物。',names(d));
    end
    % 按身份分层；同一身份可出现在三部分，但图片文件不重复。
    % 此协议用于已知身份识别，不用于陌生人物的表情泛化测试。
    rng(seed,'twister');
    manifest.Split = strings(height(manifest),1);
    for k = 1:numel(ids)
        rows = find(manifest.Label == ids(k));
        rows = rows(randperm(numel(rows)));
        n = numel(rows); nTrain = floor(0.6*n); nVal = max(1,floor(0.2*n));
        manifest.Split(rows(1:nTrain)) = "train";
        manifest.Split(rows(nTrain+1:nTrain+nVal)) = "validation";
        manifest.Split(rows(nTrain+nVal+1:end)) = "test";
    end
    writetable(manifest,fullfile(project,'manifests',names(d)+"_split.csv"));
    datasets{d} = manifest;
    row = table(names(d),numel(ids),height(manifest),height(excluded),...
        min(counts),max(counts),sum(manifest.Split=="train"),...
        sum(manifest.Split=="validation"),sum(manifest.Split=="test"),...
        'VariableNames',{'Dataset','People','Images','Excluded','MinPerPerson',...
        'MaxPerPerson','Train','Validation','Test'});
    summary = [summary;row]; %#ok<AGROW>
    previewDataset(manifest,names(d),fullfile(project,'results'));
end
writetable(summary,fullfile(project,'dataset_summary.csv'));
save(fullfile(project,'project_state.mat'),'datasets','summary','seed','project','source');
fprintf('\n===== 数据统计 =====\n'); disp(summary);
fprintf('注意：当前检查文件可读性与标签，不执行近重复图像检测。\n');
fprintf('Extended Yale B 已排除 ambient 图像；实际数量以统计为准。\n');
fprintf('\n===== ORL：首次 HOG + SVM 基线 =====\n');
baseline = runBaseline(datasets{1},fullfile(project,'results'));
writetable(baseline,fullfile(project,'baseline_summary.csv'));
disp(baseline);
fprintf('\n完成。请反馈 dataset_summary.csv、baseline_summary.csv 和三张 preview 图片。\n');
fprintf('结果目录：%s\n',project);
diary off;

function [T,E] = inspectDataset(root,dataset)
    files = dir(fullfile(root,'**','*'));
    paths = strings(0,1); labels = strings(0,1); dims = zeros(0,3);
    bad = strings(0,1); reasons = strings(0,1);
    extensions = [".pgm",".png",".jpg",".jpeg",".bmp",".tif",".tiff",".gif"];
    for i = 1:numel(files)
        if files(i).isdir, continue; end
        [~,stem,ext] = fileparts(files(i).name);
        if ~ismember(lower(string(ext)),extensions), continue; end
        p = string(fullfile(files(i).folder,files(i).name));
        reason = ""; identity = "";
        if contains(p,'__MACOSX') || startsWith(string(files(i).name),'._')
            reason = "metadata";
        elseif dataset=="ExtendedYaleB" && contains(lower(string(stem)),"ambient")
            reason = "ambient image excluded by protocol";
        end
        if dataset=="ExtendedYaleB"
            token = regexp(char(p),'(?i)yaleB(\d+)','tokens','once');
            if ~isempty(token), identity = "yaleB"+compose('%02d',str2double(token{1})); end
        elseif dataset=="GeorgiaTech"
            % 裁剪版为cropped_faces/s01_01.jpg，前一个数字是身份。
            token = regexp(char(stem),'(?i)^s(\d+)_\d+$','tokens','once');
            if ~isempty(token)
                identity = "s"+compose('%02d',str2double(token{1}));
            else
                % 同时兼容按s01文件夹存放的版本。
                [~,parentName] = fileparts(files(i).folder);
                token = regexp(parentName,'(?i)^s(\d+)$','tokens','once');
                if ~isempty(token), identity="s"+compose('%02d',str2double(token{1})); end
            end
        else
            parts = split(replace(string(files(i).folder),'\','/'),'/');
            for j = numel(parts):-1:1
                token = regexp(char(parts(j)),'(?i)^s(\d+)$','tokens','once');
                if ~isempty(token)
                    identity = "s"+compose('%02d',str2double(token{1})); break;
                end
            end
        end
        if identity=="" && reason=="", reason="unrecognized identity folder"; end
        if reason==""
            try
                [I,map] = imread(p);
                if ~isempty(map), I=ind2rgb(I,map); end
                if isempty(I) || ~ismember(size(I,3),[1 3])
                    error('Unsupported image dimensions');
                end
                paths(end+1,1)=p; labels(end+1,1)=identity; %#ok<AGROW>
                dims(end+1,:)=[size(I,1),size(I,2),size(I,3)]; %#ok<AGROW>
            catch ME
                reason="read error: "+string(ME.message);
            end
        end
        if reason~="", bad(end+1,1)=p; reasons(end+1,1)=reason; end %#ok<AGROW>
    end
    T=table(paths,labels,dims(:,1),dims(:,2),dims(:,3),...
        'VariableNames',{'File','Label','Height','Width','Channels'});
    T=sortrows(T,{'Label','File'});
    E=table(bad,reasons,'VariableNames',{'File','Reason'});
end

function previewDataset(T,name,out)
    fig=figure('Visible','off','Color','w','Position',[100 100 1100 650]);
    cleanup=onCleanup(@() close(fig));
    tiledlayout(3,4,'Padding','compact','TileSpacing','compact');
    ids=unique(T.Label);
    for k=1:min(12,numel(ids))
        row=find(T.Label==ids(k),1);
        nexttile; imshow(T.File(row)); title(ids(k),'Interpreter','none');
    end
    sgtitle(name+" - identity samples",'Interpreter','none');
    exportgraphics(fig,fullfile(out,name+"_preview.png"),'Resolution',180);
end

function result = runBaseline(T,out)
    imageSize=[112 96]; cellSize=[8 8];
    first=readGray(T.File(1),imageSize);
    nFeatures=numel(extractHOGFeatures(first,'CellSize',cellSize));
    X=zeros(height(T),nFeatures,'single');
    tic;
    for i=1:height(T)
        X(i,:)=extractHOGFeatures(readGray(T.File(i),imageSize),'CellSize',cellSize);
    end
    featureSeconds=toc;
    Y=categorical(T.Label);
    train=T.Split=="train"; val=T.Split=="validation"; test=T.Split=="test";
    % 标准化由训练数据拟合；C只通过验证集选择。
    grid=[0.01 0.1 1 10]; valAccuracy=zeros(numel(grid),1);
    best=-inf; model=[]; selectedC=NaN;
    tic;
    for k=1:numel(grid)
        learner=templateSVM('KernelFunction','linear','Standardize',true,...
            'BoxConstraint',grid(k));
        candidate=fitcecoc(X(train,:),Y(train),'Learners',learner,'Coding','onevsone');
        pred=predict(candidate,X(val,:));
        valAccuracy(k)=mean(pred==Y(val));
        fprintf('C=%g，验证准确率=%.2f%%\n',grid(k),100*valAccuracy(k));
        if valAccuracy(k)>best
            best=valAccuracy(k); model=candidate; selectedC=grid(k);
        end
    end
    tuningSeconds=toc;
    tic; predictions=predict(model,X(test,:)); predictionSeconds=toc;
    truth=Y(test); order=categorical(categories(Y));
    C=confusionmat(truth,predictions,'Order',order);
    tp=diag(C); precision=tp./max(sum(C,1)',1); recall=tp./max(sum(C,2),1);
    f1=2*precision.*recall./max(precision+recall,eps);
    accuracy=mean(predictions==truth); macroF1=mean(f1);
    result=table("ORL","HOG_SVM",selectedC,best,accuracy,macroF1,...
        featureSeconds,tuningSeconds,1000*predictionSeconds/sum(test),...
        'VariableNames',{'Dataset','Method','SelectedC','ValidationAccuracy',...
        'TestAccuracy','MacroF1','AllImagesFeatureSeconds','TuningSeconds',...
        'ClassifierOnlyMsPerTestImage'});
    writetable(table(grid(:),valAccuracy,'VariableNames',{'C','ValidationAccuracy'}),...
        fullfile(out,'ORL_HOG_validation.csv'));
    P=T(test,:); P.Prediction=string(predictions); P.Correct=predictions==truth;
    writetable(P,fullfile(out,'ORL_HOG_predictions.csv'));
    save(fullfile(out,'ORL_HOG_model.mat'),'model','imageSize','cellSize',...
        'selectedC','C','order','result');
    fig=figure('Visible','off','Position',[100 100 1100 850],'Color','w');
    cleanup=onCleanup(@() close(fig));
    confusionchart(C,string(order),'Title',sprintf('ORL HOG+SVM | Accuracy %.2f%%',100*accuracy));
    exportgraphics(fig,fullfile(out,'ORL_HOG_confusion.png'),'Resolution',180);
    fprintf('测试准确率 %.2f%%，宏平均F1 %.4f\n',100*accuracy,macroF1);
end

function I=readGray(path,targetSize)
    [I,map]=imread(path);
    if ~isempty(map), I=ind2rgb(I,map); end
    if size(I,3)==3, I=rgb2gray(I); end
    I=imresize(im2single(I),targetSize);
end