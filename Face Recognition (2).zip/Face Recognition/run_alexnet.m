%% AlexNet迁移学习：三个数据集，MATLAB R2025b
% 选择已有FaceProject目录。不解压，不改数据划分，不覆盖HOG/LBP结果。
% 各数据集重新加载ImageNet预训练权重；所有层微调，分类头学习率10倍。
% 不做数据增强，以先建立清晰基线；灰度图复制成3通道，保留0-255范围。
% 固定20轮，选择验证损失最低的模型；测试集不参与选模型。
clear; clc;
project=uigetdir(pwd,'选择 FaceProject_20260916_140101_801（含manifests）');
if isequal(project,0), return; end
cfg=struct('Seed',20260916,'BatchSize',16,'MaxEpochs',20,...
    'LearnRate',1e-4,'HeadFactor',10,'TSNEPeople',10,'PredictionRepeats',3,...
    'FeatureLayer','relu7','ActivationLayer','relu1','Augmentation','none');
names=["ORL","GeorgiaTech","ExtendedYaleB"];
required=["trainnet","imagePretrainedNetwork","minibatchpredict","tsne"];
for f=required, assert(~isempty(which(char(f))),'缺少函数%s',f); end
assert(gpuDeviceCount('available')>0,'未检测到可用GPU。');
gpu=gpuDevice; disp(gpu);
manifests=cell(3,1);
for d=1:3
    file=fullfile(project,'manifests',names(d)+"_split.csv");
    assert(isfile(file),'未找到%s，请选择含manifests的项目目录。',file);
    T=readtable(file,'TextType','string');
    assert(all(ismember({'File','Label','Split'},T.Properties.VariableNames)),'清单字段缺失');
    assert(all(isfile(T.File)),'图片路径失效，请保留前两个FaceProject目录。');
    assert(numel(unique(T.File))==height(T),'重复文件路径');
    assert(all(ismember(T.Split,["train","validation","test"])), '未知数据划分');
    ids=unique(T.Label);
    for id=ids'
        for part=["train","validation","test"]
            assert(any(T.Label==id & T.Split==part),'%s在%s中没有样本',id,part);
        end
    end
    manifests{d}=T;
end
out=fullfile(project,'experiments',['AlexNet_' char(datetime('now','Format','yyyyMMdd_HHmmss_SSS'))]);
mkdir(out); diary(fullfile(out,'run_log.txt')); logGuard=onCleanup(@() diary('off'));
fprintf('输出目录：%s\n',out);
save(fullfile(out,'config.mat'),'cfg','project');
fid=fopen(fullfile(out,'README.txt'),'w');
fprintf(fid,['AlexNet fine-tuning, MATLAB R2025b.\n' ...
    'ImageNet initialization is independent for each dataset. No data augmentation.\n' ...
    'Images: uint8 RGB in [0,255]; grayscale replicated to RGB; resized to network input.\n' ...
    'All layers trainable. Classification head learning rate factor = 10.\n' ...
    '20 epochs, SGDM, LR=1e-4. Best validation loss selects the returned network.\n' ...
    'Test data excluded from model selection. Fixed split, not repeated trials.\n' ...
    'CSV Accuracy/F1: fractions. Training history Accuracy: percent.\n' ...
    'Prediction timing includes disk read, resize, transfer and full GPU forward pass.\n' ...
    'Median of three warmed test passes with GPU synchronization.\n' ...
    'Not directly comparable to CPU SVM classifier-only timing.\n' ...
    't-SNE uses same first 10 sorted identities and test samples as HOG/LBP.\n' ...
    'GPU training is not guaranteed bitwise deterministic despite fixed seed.\n' ...
    'Figures saved as PNG 300 dpi and editable FIG.\n']); fclose(fid);
summary=table();
for d=1:3
    fprintf('\n===== %s / AlexNet =====\n',names(d));
    dest=fullfile(out,names(d)); mkdir(dest);
    T=manifests{d}; writetable(T,fullfile(dest,'split_used.csv'));
    rng(cfg.Seed,'twister'); gpurng(cfg.Seed);
    Y=categorical(T.Label); classNames=categories(Y); order=categorical(classNames);
    train=T.Split=="train"; val=T.Split=="validation"; test=T.Split=="test";
    net=imagePretrainedNetwork('alexnet','NumClasses',numel(classNames));
    inputSize=net.Layers(1).InputSize;
    % 自动定位分类头，不依赖分类层的固定名字。
    fc=find(arrayfun(@(L) isa(L,'nnet.cnn.layer.FullyConnectedLayer'),net.Layers));
    assert(~isempty(fc),'未找到全连接分类层');
    head=string(net.Layers(fc(end)).Name);
    net=setLearnRateFactor(net,head+"/Weights",cfg.HeadFactor);
    net=setLearnRateFactor(net,head+"/Bias",cfg.HeadFactor);
    assert(any(string({net.Layers.Name})==cfg.FeatureLayer),'特征层名称不匹配');
    dsTrain=makeDS(T(train,:),inputSize); dsVal=makeDS(T(val,:),inputSize);
    dsTest=makeDS(T(test,:),inputSize);
    frequency=max(1,floor(sum(train)/cfg.BatchSize));
    options=trainingOptions('sgdm','InitialLearnRate',cfg.LearnRate,...
        'Momentum',0.9,'L2Regularization',1e-4,...
        'MiniBatchSize',cfg.BatchSize,'MaxEpochs',cfg.MaxEpochs,...
        'Shuffle','every-epoch','ValidationData',dsVal,...
        'ValidationFrequency',frequency,'ValidationPatience',Inf,...
        'OutputNetwork','best-validation','ObjectiveMetricName','loss',...
        'Metrics','accuracy','ExecutionEnvironment','gpu',...
        'Verbose',true,'VerboseFrequency',frequency,'Plots','training-progress');
    wait(gpu); timer=tic;
    [net,info]=trainnet(dsTrain,net,'crossentropy',options);
    wait(gpu); trainSeconds=toc(timer);
    % 训练结束立即保存，后续绘图失败无需重训。
    save(fullfile(dest,'trained_model.mat'),'net','info','cfg','classNames','inputSize','T','trainSeconds','-v7.3');
    writetable(info.TrainingHistory,fullfile(dest,'training_history.csv'));
    writetable(info.ValidationHistory,fullfile(dest,'validation_history.csv'));
    valScores=predictScores(net,dsVal,cfg);
    scores=predictScores(net,dsTest,cfg); % 预热
    times=zeros(cfg.PredictionRepeats,1);
    for k=1:cfg.PredictionRepeats
        wait(gpu); timer=tic; predictScores(net,dsTest,cfg); wait(gpu); times(k)=toc(timer);
    end
    [~,index]=max(scores,[],2); predictions=categorical(string(classNames(index)));
    [~,index]=max(valScores,[],2); valPred=categorical(string(classNames(index)));
    truth=Y(test); C=confusionmat(truth,predictions,'Order',order);
    tp=diag(C); precision=tp./max(sum(C,1)',1); recall=tp./max(sum(C,2),1);
    f1=2*precision.*recall./max(precision+recall,eps);
    accuracy=mean(truth==predictions); macroF1=mean(f1);
    row=table(names(d),"AlexNet",sum(train),sum(val),sum(test),...
        mean(valPred==Y(val)),accuracy,macroF1,trainSeconds,...
        1000*median(times)/sum(test),info.OutputNetworkIteration,...
        'VariableNames',{'Dataset','Method','Train','Validation','Test',...
        'ValidationAccuracy','TestAccuracy','MacroF1','TrainSeconds',...
        'GPUReadResizeForwardMsPerImage','SelectedIteration'});
    summary=[summary;row]; %#ok<AGROW>
    writetable(summary,fullfile(out,'AlexNet_summary.csv'));
    P=T(test,:); P.Prediction=string(predictions); P.Correct=truth==predictions;
    P.MaxSoftmaxScore=max(scores,[],2); % 未校准分数，不用于陌生人拒识
    writetable(P,fullfile(dest,'test_predictions.csv'));
    writetable(table(string(order),precision,recall,f1,sum(C,2),...
        'VariableNames',{'Identity','Precision','Recall','F1','Support'}),fullfile(dest,'class_metrics.csv'));
    writematrix(C,fullfile(dest,'confusion_counts.csv'));
    save(fullfile(dest,'evaluation.mat'),'row','C','order','scores','valScores','P','times');
    fprintf('测试准确率 %.2f%%，宏平均F1 %.4f。开始绘图。\n',100*accuracy,macroF1);
    try
        makePlots(T,P,C,order,info,net,inputSize,cfg,names(d),dest);
    catch ME
        warning('绘图未全部完成，训练与评价已保存：%s',ME.message);
        fid=fopen(fullfile(dest,'plot_error.txt'),'w'); fprintf(fid,'%s',getReport(ME,'extended','hyperlinks','off')); fclose(fid);
    end
    clear net dsTrain dsVal dsTest
end
fig=newFigure(); bar(categorical(summary.Dataset),100*[summary.TestAccuracy summary.MacroF1]);
ylabel('Score (%)'); ylim([0 100]); legend('Accuracy','Macro-F1'); grid on;
title('AlexNet: single-split results'); writeFigure(fig,out,'all_datasets_scores');
disp(summary); fprintf('\n完成。输出目录：\n%s\n',out); diary off;

function ds=makeDS(T,inputSize)
    imds=imageDatastore(cellstr(T.File),'ReadFcn',@readRGB);
    imds.Labels=categorical(T.Label);
    ds=augmentedImageDatastore(inputSize(1:2),imds);
end
function I=readRGB(path)
    [I,map]=imread(path);
    if ~isempty(map), I=im2uint8(ind2rgb(I,map)); else, I=im2uint8(I); end
    if size(I,3)==1, I=repmat(I,1,1,3); end
    assert(size(I,3)==3,'图像必须是灰度或RGB图像');
end
function scores=predictScores(net,ds,cfg)
    reset(ds);
    scores=minibatchpredict(net,ds,'MiniBatchSize',cfg.BatchSize,...
        'ExecutionEnvironment','gpu','OutputDataFormats','BC');
    if isa(scores,'dlarray'), scores=extractdata(scores); end
    scores=gather(scores);
end
function fig=newFigure()
    fig=figure('Visible','off','Color','w','Position',[100 100 1100 750]);
end
function writeFigure(fig,out,name)
    cleanup=onCleanup(@() close(fig));
    savefig(fig,fullfile(out,name+".fig"));
    exportgraphics(fig,fullfile(out,name+".png"),'Resolution',300);
end
function makePlots(T,P,C,order,info,net,inputSize,cfg,name,out)
    ids=unique(T.Label);
    fig=newFigure(); tiledlayout(3,4,'TileSpacing','compact');
    for k=1:min(12,numel(ids))
        r=find(T.Label==ids(k),1); nexttile; imshow(T.File(r)); title(ids(k));
    end
    sgtitle(name+" - identity examples"); writeFigure(fig,out,'01_samples');
    counts=zeros(numel(ids),3); parts=["train","validation","test"];
    for k=1:numel(ids)
        for j=1:3, counts(k,j)=sum(T.Label==ids(k) & T.Split==parts(j)); end
    end
    fig=newFigure(); bar(counts,'stacked'); xticks(1:numel(ids)); xticklabels(ids); xtickangle(90);
    ylabel('Images'); legend(parts); title(name+" - fixed split"); writeFigure(fig,out,'02_sample_counts');
    fig=newFigure(); tiledlayout(3,2,'TileSpacing','compact');
    for k=1:3
        r=find(T.Label==ids(k) & T.Split=="train",1);
        nexttile; imshow(T.File(r)); title("Original: "+ids(k));
        nexttile; imshow(imresize(readRGB(T.File(r)),inputSize(1:2))); title('Network RGB input');
    end
    writeFigure(fig,out,'03_preprocessing');
    % 曲线来自trainnet原始记录，不平滑、不伪造逐轮数据。
    A=info.TrainingHistory; B=info.ValidationHistory;
    fig=newFigure(); tiledlayout(2,1);
    nexttile; plot(A.Iteration,historyColumn(A,{'Loss','TrainingLoss'}),'LineWidth',1); hold on;
    plot(B.Iteration,historyColumn(B,{'Loss','ValidationLoss'}),'-o','LineWidth',1.5); grid on;
    xline(info.OutputNetworkIteration,'--','Selected'); ylabel('Cross-entropy loss');
    legend('Training minibatch','Validation'); title(name+" - learning curves");
    nexttile; plot(A.Iteration,historyColumn(A,{'Accuracy','TrainingAccuracy'}),'LineWidth',1); hold on;
    plot(B.Iteration,historyColumn(B,{'Accuracy','ValidationAccuracy'}),'-o','LineWidth',1.5); grid on;
    xline(info.OutputNetworkIteration,'--','Selected'); ylim([0 100]);
    ylabel('Accuracy (%)'); xlabel('Iteration'); legend('Training minibatch','Validation');
    writeFigure(fig,out,'04_training_curves');
    fig=newFigure(); confusionchart(C,string(order),'Title',char(name+" - test counts"));
    writeFigure(fig,out,'05_confusion_counts');
    fig=newFigure(); confusionchart(C,string(order),'Normalization','row-normalized',...
        'Title',char(name+" - normalized confusion")); writeFigure(fig,out,'06_confusion_normalized');
    for flag=[true false]
        rows=find(P.Correct==flag); fig=newFigure(); tiledlayout(3,4,'TileSpacing','compact');
        if isempty(rows), nexttile; axis off; text(0,0.5,'No cases in this category'); end
        for k=1:min(12,numel(rows))
            r=rows(k); nexttile; imshow(P.File(r));
            title("True: "+P.Label(r)+" | Pred: "+P.Prediction(r),'FontSize',9,'Interpreter','none');
        end
        if flag, label="07_correct_cases"; else, label="08_error_cases"; end
        sgtitle(name+" - "+replace(label,'_',' ')); writeFigure(fig,out,label);
    end
    % 与HOG/LBP相同的前10个身份、相同测试照片。
    selectedIds=ids(1:min(cfg.TSNEPeople,numel(ids)));
    S=T(T.Split=="test" & ismember(T.Label,selectedIds),:);
    ds=makeDS(S,inputSize);
    features=minibatchpredict(net,ds,'MiniBatchSize',cfg.BatchSize,...
        'ExecutionEnvironment','gpu','Outputs',cfg.FeatureLayer,'OutputDataFormats','BC');
    if isa(features,'dlarray'), features=extractdata(features); end
    features=gather(features); assert(size(features,1)==height(S),'特征行数与样本数不一致');
    Z=double(features); Z=Z(:,std(Z,0,1)>0);
    rng(cfg.Seed,'twister'); perplexity=min(30,max(2,floor((height(S)-1)/3)));
    components=min([50,size(Z,2),height(S)-1]);
    embedding=tsne(Z,'Algorithm','exact','NumPCAComponents',components,...
        'Perplexity',perplexity,'Standardize',false);
    S.TSNE1=embedding(:,1); S.TSNE2=embedding(:,2);
    writetable(S,fullfile(out,'tsne_test_samples.csv'));
    save(fullfile(out,'tsne_features.mat'),'S','features','embedding','perplexity','components','selectedIds');
    fig=newFigure(); hold on; colors=lines(numel(selectedIds));
    for k=1:numel(selectedIds)
        mask=S.Label==selectedIds(k);
        scatter(embedding(mask,1),embedding(mask,2),55,colors(k,:),'filled','DisplayName',char(selectedIds(k)));
    end
    legend('Location','eastoutside'); grid on; xlabel('t-SNE 1'); ylabel('t-SNE 2');
    title(sprintf('%s - AlexNet test features (%d images; exploratory)',name,height(S)));
    writeFigure(fig,out,'09_tsne');
    % 特征图：第一个训练样本，固定展示前12个通道，不等同于注意力解释。
    r=find(T.Split=="train",1); I=imresize(readRGB(T.File(r)),inputSize(1:2));
    netCPU=dlupdate(@gather,net);
    act=predict(netCPU,dlarray(single(I),'SSCB'),'Outputs',cfg.ActivationLayer);
    act=gather(extractdata(act));
    fig=newFigure(); tiledlayout(3,4,'TileSpacing','compact');
    for k=1:min(12,size(act,3))
        nexttile; imshow(act(:,:,k),[]); title("Channel "+k);
    end
    sgtitle(name+" - relu1 activations (each channel scaled separately)");
    writeFigure(fig,out,'10_feature_maps');
end

function values=historyColumn(T,candidates)
    actual=T.Properties.VariableNames;
    for k=1:numel(candidates)
        idx=find(strcmpi(actual,candidates{k}),1);
        if ~isempty(idx), values=T.(actual{idx}); return; end
    end
    error('训练记录中找不到%s，实际字段：%s',strjoin(candidates,','),strjoin(actual,','));
end
