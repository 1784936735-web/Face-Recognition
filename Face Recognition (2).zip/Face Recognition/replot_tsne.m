%% 只重画t-SNE，不重新训练（MATLAB R2025b）
% 选择汇总Comparison目录，读取selected_runs.csv锁定原来的五次实验。
% 固定每个数据集前10个身份；选用训练+测试照片，排除验证照片。
% 联合降维是描述性可视化，不是独立测试性能，不改变任何模型/预测。
clear; clc;
folder=uigetdir(pwd,'选择含 selected_runs.csv 的 Comparison_日期时间 文件夹');
if isequal(folder,0), return; end
sourceFile=fullfile(folder,'selected_runs.csv');
assert(isfile(sourceFile),'选错目录：请选择summaries下含selected_runs.csv的Comparison文件夹。');
% 显式指定格式：避免自动检测把纯文本CSV的首行当作数据。
runs=readtable(sourceFile,'FileType','text','Delimiter',',',...
    'Encoding','UTF-8','ReadVariableNames',true,'NumHeaderLines',0,...
    'VariableNamingRule','preserve','TextType','string');
assert(all(ismember({'Method','SourceRun'},runs.Properties.VariableNames)),...
    '清单列名异常，实际读取到：%s',strjoin(runs.Properties.VariableNames,', '));
runs.Method=strip(string(runs.Method));
runs.SourceRun=strip(string(runs.SourceRun));
fprintf('已读取实验清单：%d种方法。\n',height(runs));
methods=["HOG_SVM","LBP_SVM","AlexNet","ResNet50","MobileNetV2"];
labels=["HOG + SVM","LBP + SVM","AlexNet","ResNet50","MobileNetV2"];
names=["ORL","GeorgiaTech","ExtendedYaleB"];
roots=strings(5,1);
for m=1:5
    idx=find(runs.Method==methods(m));
    assert(numel(idx)==1,'运行清单中缺少或重复方法%s',methods(m));
    roots(m)=runs.SourceRun(idx);
    assert(isfolder(roots(m)),'原实验目录不存在：%s',roots(m));
end
cfg=struct('Seed',20260916,'People',10,'MiniBatchSize',16,...
    'Algorithm','exact','Standardize',false,'MaxPCAComponents',50);
% 十个不重复的固定颜色，不使用会循环的默认七色列表。
colors=[31 119 180;255 127 14;44 160 44;214 39 40;148 103 189;...
    140 86 75;227 119 194;105 105 105;188 189 34;23 190 207]/255;
assert(size(unique(colors,'rows'),1)==cfg.People,'颜色重复');
environment='cpu';
if exist('gpuDeviceCount','file') && gpuDeviceCount('available')>0, environment='gpu'; end
out=fullfile(folder,['TSNE_joint_' char(datetime('now','Format','yyyyMMdd_HHmmss_SSS'))]);
mkdir(out); diary(fullfile(out,'run_log.txt')); logGuard=onCleanup(@() diary('off'));
writetable(runs,fullfile(out,'selected_runs.csv')); save(fullfile(out,'settings.mat'),'cfg','colors','environment');
fid=fopen(fullfile(out,'README.txt'),'w');
fprintf(fid,['TRAIN + TEST joint embedding; validation samples excluded.\n' ...
    'Descriptive feature visualization, NOT independent held-out performance.\n' ...
    'No training, tuning, classification or change to existing results.\n' ...
    'First 10 lexicographically sorted identities; all train/test samples for these identities.\n' ...
    'Same files and labels used by all five methods.\n' ...
    'Identity=color (10 unique colors), train=circle, test=triangle.\n' ...
    'Raw features with constant dimensions removed; PCA up to 50 dimensions; no standardization.\n' ...
    'One fixed t-SNE run per method, not selected by visual appearance.\n' ...
    'Embedding axes have no physical units and are independent across methods.\n' ...
    'Do not infer cross-method superiority from cluster spacing alone.\n' ...
    'Exact image paths, labels, split and coordinates saved as CSV.\n']); fclose(fid);
for d=1:3
    fprintf('\n===== %s：训练+测试联合展示 =====\n',names(d));
    dest=fullfile(out,names(d)); mkdir(dest);
    reference=readtable(fullfile(roots(1),names(d),'split_used.csv'),'FileType','text','Delimiter',',',...
        'Encoding','UTF-8','ReadVariableNames',true,'NumHeaderLines',0,...
        'VariableNamingRule','preserve','TextType','string');
    reference=sortrows(reference(:,{'File','Label','Split'}),'File');
    ids=unique(reference.Label); ids=ids(1:min(cfg.People,numel(ids)));
    S=reference(ismember(reference.Label,ids) & ismember(reference.Split,["train","test"]),:);
    assert(numel(unique(S.File))==height(S),'样本路径重复');
    fprintf('身份数%d，训练%d张，测试%d张，总计%d张。\n',numel(ids),sum(S.Split=="train"),sum(S.Split=="test"),height(S));
    writetable(S,fullfile(dest,'samples_used.csv'));
    writetable(table(ids,colors(1:numel(ids),1),colors(1:numel(ids),2),colors(1:numel(ids),3),...
        'VariableNames',{'Identity','R','G','B'}),fullfile(dest,'identity_colors.csv'));
    embeddings=cell(5,1);
    for m=1:5
        fprintf('%s：读取已保存特征/提取已训练网络特征……\n',methods(m));
        run=fullfile(roots(m),names(d));
        T=readtable(fullfile(run,'split_used.csv'),'FileType','text','Delimiter',',',...
        'Encoding','UTF-8','ReadVariableNames',true,'NumHeaderLines',0,...
        'VariableNamingRule','preserve','TextType','string');
        T=sortrows(T(:,{'File','Label','Split'}),'File');
        assert(isequal(T,reference),'%s的划分与基准不一致',methods(m));
        if m<=2
            modelFile=fullfile(run,'experiment.mat');
            D=load(modelFile,'T','X');
            [found,index]=ismember(S.File,string(D.T.File));
            assert(all(found),'已保存特征中缺少选定图像');
            assert(isequal(string(D.T.Label(index)),S.Label) && ...
                isequal(string(D.T.Split(index)),S.Split),'特征元数据不一致');
            X=double(D.X(index,:)); clear D
            featureLayer="handcrafted";
        else
            D=load(fullfile(run,'trained_model.mat'),'net','cfg','inputSize');
            assert(all(isfile(S.File)),'原图路径失效，请保留旧项目数据文件夹');
            imds=imageDatastore(cellstr(S.File),'ReadFcn',@readRGB);
            ds=augmentedImageDatastore(D.inputSize(1:2),imds);
            featureLayer=string(D.cfg.FeatureLayer);
            if m==3, layout='BC'; else, layout='BCSS'; end
            X=minibatchpredict(D.net,ds,'MiniBatchSize',cfg.MiniBatchSize,...
                'ExecutionEnvironment',environment,'Outputs',featureLayer,'OutputDataFormats',layout);
            if isa(X,'dlarray'), X=extractdata(X); end
            X=gather(X); assert(size(X,1)==height(S),'特征批次维度错误');
            X=double(reshape(X,height(S),[])); clear D ds imds
        end
        assert(all(isfinite(X),'all'),'特征存在NaN或Inf');
        varying=std(X,0,1)>0; Z=X(:,varying);
        assert(size(Z,2)>=2,'有效特征维数不足');
        components=min([cfg.MaxPCAComponents,size(Z,2),height(S)-1]);
        perplexity=min(30,max(2,floor((height(S)-1)/3)));
        rng(cfg.Seed,'twister');
        [embedding,loss]=tsne(Z,'Algorithm',cfg.Algorithm,'NumDimensions',2,...
            'NumPCAComponents',components,'Perplexity',perplexity,'Standardize',cfg.Standardize);
        embeddings{m}=embedding;
        C=S; C.TSNE1=embedding(:,1); C.TSNE2=embedding(:,2);
        writetable(C,fullfile(dest,methods(m)+"_coordinates.csv"));
        save(fullfile(dest,methods(m)+"_embedding.mat"),'S','X','embedding','loss',...
            'cfg','components','perplexity','featureLayer','varying','-v7.3');
        fig=figure('Visible','off','Color','w','Position',[100 100 1100 800]);
        ax=axes(fig); drawPoints(ax,S,embedding,ids,colors);
        title(ax,names(d)+" / "+labels(m)+" - train + test (exploratory)");
        addLegend(ax,ids,colors); writeFigure(fig,dest,methods(m)+"_joint_tsne");
        fprintf('完成：%d个点，perplexity=%g，KL loss=%.4f（不用于方法排名）。\n',height(S),perplexity,loss);
    end
    fig=figure('Visible','off','Color','w','Position',[50 50 1500 900]);
    tiledlayout(fig,2,3,'TileSpacing','compact','Padding','compact');
    for m=1:5
        ax=nexttile; drawPoints(ax,S,embeddings{m},ids,colors); title(ax,labels(m));
    end
    ax=nexttile; axis(ax,'off'); addLegend(ax,ids,colors);
    sgtitle(sprintf('%s | TRAIN + TEST joint t-SNE | %d identities, %d images | exploratory',names(d),numel(ids),height(S)));
    writeFigure(fig,out,names(d)+"_joint_tsne_comparison");
end
fprintf('\n全部完成，未修改任何训练结果。输出目录：\n%s\n',out); diary off;

function I=readRGB(path)
    [I,map]=imread(path);
    if ~isempty(map), I=im2uint8(ind2rgb(I,map)); else, I=im2uint8(I); end
    if size(I,3)==1, I=repmat(I,1,1,3); end
end
function drawPoints(ax,S,Y,ids,colors)
    hold(ax,'on');
    for k=1:numel(ids)
        a=S.Label==ids(k) & S.Split=="train";
        b=S.Label==ids(k) & S.Split=="test";
        scatter(ax,Y(a,1),Y(a,2),30,colors(k,:),'o','filled','HandleVisibility','off');
        scatter(ax,Y(b,1),Y(b,2),65,colors(k,:),'^','filled',...
            'MarkerEdgeColor','k','LineWidth',0.65,'HandleVisibility','off');
    end
    xlabel(ax,'t-SNE 1'); ylabel(ax,'t-SNE 2'); grid(ax,'on');
    % 每幅图使用其自身完整坐标范围，不截掉任何点。
    axis(ax,'padded'); set(ax,'FontSize',11);
end
function addLegend(ax,ids,colors)
    hold(ax,'on');
    for k=1:numel(ids)
        scatter(ax,NaN,NaN,40,colors(k,:),'o','filled','DisplayName',char(ids(k)));
    end
    scatter(ax,NaN,NaN,40,[0.3 0.3 0.3],'o','filled','DisplayName','Training');
    scatter(ax,NaN,NaN,65,[0.3 0.3 0.3],'^','filled','MarkerEdgeColor','k','DisplayName','Test');
    legend(ax,'Location','eastoutside','Interpreter','none');
end
function writeFigure(fig,folder,name)
    cleanup=onCleanup(@() close(fig));
    savefig(fig,fullfile(folder,string(name)+".fig"));
    exportgraphics(fig,fullfile(folder,string(name)+".png"),'Resolution',300);
end
