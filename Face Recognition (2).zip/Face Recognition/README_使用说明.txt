人脸身份识别实验——MATLAB 源代码使用说明
======================================

作者：李瑞涛
实验内容：在 ORL、GeorgiaTech、Extended Yale B 三个人脸数据集上比较
HOG + SVM、LBP + SVM、AlexNet、ResNet50、MobileNetV2 五种身份识别方法。
本套代码做的是“已知身份的人脸识别”；没有实现表情识别，也不把陌生人
识别为“未知身份”。

一、运行环境
------------
已实际使用 MATLAB R2025b Update 2、Windows 11、NVIDIA RTX 4060 Laptop GPU。
需要 Image Processing Toolbox、Computer Vision Toolbox、Statistics and
Machine Learning Toolbox、Deep Learning Toolbox、Parallel Computing
Toolbox。三种网络还需分别安装 AlexNet、ResNet-50、MobileNet-v2 的
Deep Learning Toolbox 预训练模型支持包。网络训练脚本要求有可用 GPU。
其他 MATLAB 版本或设备未单独验证。

二、文件及用途
--------------
start_face_project.m   解压并检查三个数据集，生成固定划分与初始 ORL 基线。
run_hog_svm.m          三个数据集的 HOG 特征 + SVM 实验。
run_lbp_svm.m          三个数据集的 LBP 特征 + SVM 实验。
run_alexnet.m          AlexNet 预训练网络迁移学习实验。
run_resnet50.m         ResNet50 预训练网络迁移学习实验。
run_mobilenetv2.m      MobileNetV2 预训练网络迁移学习实验。
summarize_results.m    核对相同划分及逐图预测，汇总 15 组实验并绘图。
replot_tsne.m          依据已保存的特征和模型重画联合 t-SNE，不重新训练。
demo_five_methods.m    选择数据集、方法及一张原测试集图片，显示识别结果。

上述 .m 文件均放在本文件同一目录。demo_five_methods 是支持多方法选择
的演示程序；旧版 demo_orl_lbp.m 不属于本提交的必要运行路径。

三、数据准备
------------
首次运行时，将以下三个压缩包放在同一个数据目录，保留原文件名：
  att_faces.zip、GTdb_crop.zip、CroppedYale.zip。
在 MATLAB 中打开本源代码目录，在命令窗口输入 start_face_project 并回车，
按弹窗提示选择上述三个 ZIP 所在目录。程序自动建立带时间戳的
FaceProject_... 项目目录，在其中保存 raw/、manifests/、results/、
dataset_summary.csv 等。固定随机种子为 20260916，按人物划分训练集、
验证集和测试集。首次脚本同时计算一个 ORL 的 HOG + SVM 初步基线；
正式五方法比较使用下述独立实验脚本。

若已提供并保留原先完整的 FaceProject_... 项目目录，且其中
manifests/ORL_split.csv、GeorgiaTech_split.csv、ExtendedYaleB_split.csv
及 CSV 内记录的原始图像路径仍然有效，则无需重复运行首个脚本。
CSV 的 File 列是本机路径：直接将项目目录复制到另一台电脑后，路径可能
失效。此时建议在该电脑上从三个 ZIP 重新运行 start_face_project，
生成本地项目，再运行后续实验。不得只复制 split.csv 而丢失 raw 图像。

四、推荐运行顺序
----------------
1. 将源代码目录设为 MATLAB 当前文件夹，或用 addpath 添加该目录。
2. 完成第三节的数据准备；记住生成的 FaceProject_... 项目目录。
3. 在 MATLAB 命令窗口依次运行：
       run_hog_svm
       run_lbp_svm
       run_alexnet
       run_resnet50
       run_mobilenetv2
   每次均在弹窗中选择同一个 FaceProject_... 项目目录。五种方法分别
   使用三个数据集的相同训练/验证/测试划分，各自创建一个带时间戳的
   experiments/方法名_... 结果目录，互不覆盖。深度学习训练时间较长。
4. 五种方法都完成三个数据集后，运行 summarize_results，同样选择
   FaceProject_... 项目目录。如果某个方法存在多个完整运行目录，按
   弹窗选择本报告采用的那次实验。汇总程序检查 15 组实验的文件路径、
   身份标签、划分及逐图预测，结果在 summaries/Comparison_... 中。
5. 如需重画报告中的联合 t-SNE，运行 replot_tsne，选择上一步产生且
   含有 selected_runs.csv 的 Comparison_... 文件夹。输出在该目录下
   的 TSNE_joint_... 子目录；该步骤不训练模型、不改变测试结果。
6. 如需现场展示识别，运行 demo_five_methods，选择同一个
   Comparison_... 文件夹，再在弹窗中选择数据集、一个或多个方法、
   一张原测试集图片。窗口显示输入图和预测身份的训练参考图，同时
   将逐方法预测记录及演示图保存在 SingleImage_... 子目录。

五、结果目录与指标
------------------
FaceProject_.../
  raw/                        解压后的原始图像，可能复用较早的项目目录
  manifests/*_split.csv       三个数据集的固定划分及图像绝对路径
  results/                    数据预览及首次 ORL 基线
  experiments/HOG_SVM_.../    HOG + SVM 运行结果
  experiments/LBP_SVM_.../    LBP + SVM 运行结果
  experiments/AlexNet_.../    AlexNet 运行结果
  experiments/ResNet50_.../   ResNet50 运行结果
  experiments/MobileNetV2_.../MobileNetV2 运行结果
  summaries/Comparison_.../   比较表、图、selected_runs.csv 等

每个正式实验目录通常保存方法汇总 CSV、三个按数据集命名的子目录，
其中包括 split_used.csv、test_predictions.csv、混淆矩阵与图像，
以及 experiment.mat（SVM）或 trained_model.mat（神经网络）。
汇总目录的 accuracy_percent.csv 使用百分数，macro_f1.csv 使用 0～1
小数；单方法的准确率/F1 汇总表使用 0～1 小数。不能把训练曲线中的
百分数与小数直接比较。CPU 的 SVM 分类器计时和 GPU 网络的图像读取、
缩放与前向推理计时范围不同，不宜直接当作同口径速度排行。

六、复现与展示须知
------------------
本报告的主要比较是固定的一次划分，随机种子 20260916；五种方法在
三数据集上合计 15 组。SVM 的 C 从 0.01、0.1、1、10 中按验证集
准确率选择；神经网络训练 20 轮，按最低验证损失保留模型，测试集
不参与调参。固定种子并不保证不同 GPU 或软件版本逐位相同。

程序按已有数据集的身份编号进行分类。单图演示请使用弹窗内的原测试
图片；直接选择任意网络图片或未注册人物，不能据此证明其真实身份。
参考图只用于人工对照，不参与这张测试图的预测。t-SNE 仅用于观察
特征分布，二维坐标或 KL loss 不应作为模型准确率排序依据。

仅提交本 ZIP 可以阅读与检查源码；若要让老师独立运行并复现实验，
还需提供上述三个原始数据集 ZIP，或提供完整的项目数据目录。
如需免重训直接演示，还须一并提供所选五方法训练得到的模型文件、
原始图像以及 Comparison_.../selected_runs.csv，且更新跨电脑失效的
绝对路径。请勿仅拷贝源代码 ZIP 后直接运行汇总或单图演示。
