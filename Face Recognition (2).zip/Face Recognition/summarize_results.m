%% 五种人脸识别方法汇总（MATLAB R2025b）
% 仅读取CSV和图片，不加载模型，不训练，不修改原始实验。
% 多次运行时让用户选择，不按测试成绩挑选，也不悄悄混合多次实验。
clear; clc;
project=uigetdir(pwd,'选择含experiments和manifests的FaceProject目录');
if isequal(project,0), return; end
methods=["HOG_SVM","LBP_SVM","AlexNet","ResNet50","MobileNetV2"];
labels=["HOG + SVM","LBP + SVM","AlexNet","ResNet50","MobileNetV2"];
datasets=["ORL","GeorgiaTech","ExtendedYaleB"];
roots=strings(5,1); summaries=cell(5,1);
for m=1:5
    candidates=dir(fullfile(project,'experiments',methods(m)+"_*"));
    candidates=candidates([candidates.isdir]); valid=strings(0,1);
    for k=1:numel(candidates)
        root=string(fullfile(candidates(k).folder,candidates(k).name));
        summaryPath=fullfile(root,methods(m)+"_summary.csv");
        if ~isfile(summaryPath), continue; end
        A=readtable(summaryPath,'TextType','string');
        if ~ismember('Dataset',A.Properties.VariableNames), continue; end
        complete=height(A)==3 && all(ismember(datasets,string(A.Dataset)));
        for d=1:3
            complete=complete && isfile(fullfile(root,datasets(d),'split_used.csv')) ...
                && isfile(fullfile(root,datasets(d),'test_predictions.csv'));
        end
        if complete, valid(end+1,1)=root; end %#ok<SAGROW>
    end
    assert(~isempty(valid),'%s没有完整结果：需要三个数据集的汇总、划分和预测CSV。',methods(m));
    if numel(valid)>1
        [choice,ok]=listdlg('PromptString',char("选择要汇总的 "+methods(m)+" 运行"),...
            'SelectionMode','single','ListString',cellstr(valid),'ListSize',[850 220]);
        if ~ok, disp('已取消，未改变任何实验文件。'); return; end
    else, choice=1;
    end
    roots(m)=valid(choice);
    summaries{m}=readtable(fullfile(roots(m),methods(m)+"_summary.csv"),'TextType','string');
end
acc=zeros(3,5); f1=acc; trainSeconds=acc; svmTime=nan(3,2); gpuTime=nan(3,3);
allResults=table(); references=cell(3,1); predictions=cell(3,5);
for d=1:3
    reference=readtable(fullfile(project,'manifests',datasets(d)+"_split.csv"),'TextType','string');
    reference=sortrows(reference(:,{'File','Label','Split'}),'File');
    assert(numel(unique(reference.File))==height(reference),'基准清单路径重复');
    references{d}=reference;
    for m=1:5
        T=readtable(fullfile(roots(m),datasets(d),'split_used.csv'),'TextType','string');
        T=sortrows(T(:,{'File','Label','Split'}),'File');
        assert(isequal(T,reference),'%s / %s的数据划分与项目基准不一致，停止汇总。',datasets(d),methods(m));
        A=summaries{m}; r=find(string(A.Dataset)==datasets(d));
        assert(numel(r)==1 && string(A.Method(r))==methods(m),'汇总表的方法/数据集字段不正确');
        P=readtable(fullfile(roots(m),datasets(d),'test_predictions.csv'),'TextType','string');
        P=sortrows(P,'File'); expected=reference(reference.Split=="test",:);
        assert(isequal(P.File,expected.File) && isequal(P.Label,expected.Label),...
            '%s / %s测试照片或真实标签不一致',datasets(d),methods(m));
        predictions{d,m}=P;
        ids=unique(reference.Label); assert(all(ismember(P.Prediction,ids)),'预测含未知标签');
        C=confusionmat(categorical(P.Label,ids),categorical(P.Prediction,ids),...
            'Order',categorical(ids,ids));
        tp=diag(C); pr=tp./max(sum(C,1)',1); re=tp./max(sum(C,2),1);
        acc(d,m)=mean(P.Label==P.Prediction);
        f1(d,m)=mean(2*pr.*re./max(pr+re,eps));
        assert(abs(acc(d,m)-A.TestAccuracy(r))<1e-5 && abs(f1(d,m)-A.MacroF1(r))<1e-5,...
            '%s / %s预测明细与汇总指标不一致',datasets(d),methods(m));
        assert(A.Train(r)==sum(reference.Split=="train") && ...
            A.Validation(r)==sum(reference.Split=="validation") && A.Test(r)==height(P),...
            '汇总表样本数量不一致');
        trainSeconds(d,m)=A.TrainSeconds(r);
        if m<=2
            svmTime(d,m)=A.ClassifierMsPerImage(r); time=svmTime(d,m);
            timingScope="CPU classifier only; warm batched average";
        else
            gpuTime(d,m-2)=A.GPUReadResizeForwardMsPerImage(r); time=gpuTime(d,m-2);
            timingScope="GPU read + resize + transfer + full forward; warm batched average";
        end
        row=table(datasets(d),methods(m),A.Train(r),A.Validation(r),height(P),...
            sum(P.Label==P.Prediction),100*A.ValidationAccuracy(r),100*acc(d,m),f1(d,m),...
            trainSeconds(d,m),time,timingScope,roots(m),...
            'VariableNames',{'Dataset','Method','Train','Validation','Test','Correct',...
            'ValidationAccuracyPercent','TestAccuracyPercent','MacroF1','TrainSeconds',...
            'PredictionMsPerImage','TimingScope','SourceRun'});
        allResults=[allResults;row]; %#ok<AGROW>
    end
end
fprintf('检查通过：15组实验划分一致，指标与逐图预测一致。\n');
out=fullfile(project,'summaries',['Comparison_' char(datetime('now','Format','yyyyMMdd_HHmmss_SSS'))]);
mkdir(out); diary(fullfile(out,'summary_log.txt')); logGuard=onCleanup(@() diary('off'));
writetable(allResults,fullfile(out,'all_results.csv'));
writetable(table(methods',roots,'VariableNames',{'Method','SourceRun'}),fullfile(out,'selected_runs.csv'));
A=array2table(100*acc,'VariableNames',cellstr(methods)); A=addvars(A,datasets','Before',1,'NewVariableNames','Dataset');
writetable(A,fullfile(out,'accuracy_percent.csv'));
F=array2table(f1,'VariableNames',cellstr(methods)); F=addvars(F,datasets','Before',1,'NewVariableNames','Dataset');
writetable(F,fullfile(out,'macro_f1.csv'));
save(fullfile(out,'comparison_data.mat'),'acc','f1','trainSeconds','svmTime','gpuTime','roots','methods','datasets','allResults');
fid=fopen(fullfile(out,'README.txt'),'w');
fprintf(fid,['Single fixed split; no confidence intervals or repeated-run statistics.\n' ...
    'All 15 splits were matched against project manifests by full path, label and split.\n' ...
    'Test accuracy and macro-F1 recomputed from predictions and matched to summaries.\n' ...
    'Accuracy CSV is percent, macro-F1 CSV is 0..1.\n' ...
    'SVM timing: CPU classifier only; CNN timing: GPU read+resize+transfer+forward.\n' ...
    'These two timing scopes are plotted separately.\n' ...
    'SVM TrainSeconds means selected candidate fit, excluding C search and feature extraction.\n' ...
    'CNN TrainSeconds includes training and periodic validation.\n' ...
    'Do not interpret cross-group training times as an equal-budget benchmark.\n' ...
    't-SNE panels use existing coordinates; axes differ and cluster spacing is not an accuracy metric.\n' ...
    'Training curves compare validation histories against iteration or epoch, not raw time.\n' ...
    'Source run choices are recorded in selected_runs.csv. Source files unchanged.\n']); fclose(fid);
colors=lines(5);
barPlot(100*acc,datasets,labels,colors,'Test accuracy (%)','Test accuracy: same fixed split',out,'01_accuracy',true);
barPlot(100*f1,datasets,labels,colors,'Macro-F1 (%)','Macro-F1: same fixed split',out,'02_macro_f1',true);
for item=1:2
    if item==1, data=100*acc; titleText='Test accuracy (%)'; filename='03_accuracy_heatmap';
    else, data=100*f1; titleText='Macro-F1 (%)'; filename='04_f1_heatmap'; end
    fig=newFigure(); h=heatmap(labels,datasets,data); h.Title=titleText;
    h.ColorLimits=[0 100]; h.CellLabelFormat='%.2f'; writeFigure(fig,out,filename);
end
barPlot(svmTime,datasets,labels(1:2),colors(1:2,:),'Milliseconds / image',...
    'CPU SVM classification only (excludes feature extraction)',out,'05_svm_prediction_time',false);
barPlot(gpuTime,datasets,labels(3:5),colors(3:5,:),'Milliseconds / image',...
    'GPU CNN prediction including read, resize and transfer',out,'06_cnn_prediction_time',false);
barPlot(trainSeconds(:,1:2),datasets,labels(1:2),colors(1:2,:),'Seconds',...
    'CPU SVM selected fit only (excludes tuning and features)',out,'07_svm_fit_time',false);
barPlot(trainSeconds(:,3:5),datasets,labels(3:5),colors(3:5,:),'Seconds',...
    'GPU CNN training including validation',out,'08_cnn_training_time',false);
for group=1:2
    if group==1, range=1:2; timing=svmTime; scope='CPU classifier only';
    else, range=3:5; timing=gpuTime; scope='GPU read + resize + forward'; end
    fig=newFigure(); tiledlayout(1,3,'TileSpacing','compact');
    for d=1:3
        nexttile; hold on;
        for k=1:numel(range)
            m=range(k); scatter(timing(d,k),100*acc(d,m),90,colors(m,:),'filled','DisplayName',labels(m));
        end
        xlabel('Milliseconds / image'); ylabel('Test accuracy (%)'); ylim([0 100]);
        grid on; title(datasets(d)); legend('Location','best');
    end
    sgtitle("Accuracy / prediction time: "+scope);
    writeFigure(fig,out,"09_tradeoff_group_"+group);
end
% 非核心图片失败只记录警告，已生成的总表和对比图保留。
for d=1:3
    try
        fig=newFigure(); tiledlayout(2,1); ax1=nexttile; hold(ax1,'on'); ax2=nexttile; hold(ax2,'on');
        for m=3:5
            root=fullfile(roots(m),datasets(d));
            H=readtable(fullfile(root,'training_history.csv'));
            V=readtable(fullfile(root,'validation_history.csv'));
            % 使用训练表Epoch，将验证迭代映射到已完成/正在进行的轮次。
            epoch=interp1(double(H.Iteration),double(H.Epoch),double(V.Iteration),'previous','extrap');
            epoch(V.Iteration==0)=0;
            plot(ax1,epoch,column(V,{'Loss','ValidationLoss'}),'-o','Color',colors(m,:),'DisplayName',labels(m),'LineWidth',1.4);
            plot(ax2,epoch,column(V,{'Accuracy','ValidationAccuracy'}),'-o','Color',colors(m,:),'DisplayName',labels(m),'LineWidth',1.4);
        end
        ylabel(ax1,'Validation loss'); ylabel(ax2,'Validation accuracy (%)'); ylim(ax2,[0 100]);
        xlabel(ax1,'Epoch'); xlabel(ax2,'Epoch'); grid(ax1,'on'); grid(ax2,'on');
        legend(ax1,'Location','best'); legend(ax2,'Location','best'); sgtitle(datasets(d)+" - CNN validation curves");
        writeFigure(fig,out,"10_validation_curves_"+datasets(d));
    catch ME, warning('训练曲线未完成 %s：%s',datasets(d),ME.message); end
    try
        samples=cell(5,1);
        for m=1:5
            samples{m}=sortrows(readtable(fullfile(roots(m),datasets(d),'tsne_test_samples.csv'),'TextType','string'),'File');
            if m>1
                assert(isequal(samples{m}.File,samples{1}.File) && isequal(samples{m}.Label,samples{1}.Label),'t-SNE样本不同');
            end
        end
        ids=unique(samples{1}.Label); palette=lines(numel(ids));
        fig=newFigure(); tiledlayout(2,3,'TileSpacing','compact');
        for m=1:5
            nexttile; hold on; S=samples{m};
            for k=1:numel(ids)
                q=S.Label==ids(k); scatter(S.TSNE1(q),S.TSNE2(q),25,palette(k,:),'filled','DisplayName',ids(k));
            end
            title(labels(m)); xlabel('t-SNE 1'); ylabel('t-SNE 2'); grid on;
        end
        nexttile; hold on;
        for k=1:numel(ids), scatter(NaN,NaN,25,palette(k,:),'filled','DisplayName',ids(k)); end
        axis off; legend('Location','best'); sgtitle(datasets(d)+" - same test samples; independent embeddings");
        writeFigure(fig,out,"11_tsne_comparison_"+datasets(d));
    catch ME, warning('t-SNE拼图未完成 %s：%s',datasets(d),ME.message); end
    % 同一测试图像是否被不同方法认错：导出完整表供错误分析。
    P=predictions{d,1}; E=P(:,{'File','Label'});
    for m=1:5, E.(char(methods(m)))=predictions{d,m}.Prediction; end
    writetable(E,fullfile(out,datasets(d)+"_prediction_comparison.csv"));
end
disp(A); fprintf('\n汇总完成，无需重训。结果目录：\n%s\n',out); diary off;

function values=column(T,candidates)
    for k=1:numel(candidates)
        idx=find(strcmpi(T.Properties.VariableNames,candidates{k}),1);
        if ~isempty(idx), values=T.(T.Properties.VariableNames{idx}); return; end
    end
    error('记录缺少字段%s',strjoin(candidates,','));
end
function fig=newFigure()
    fig=figure('Visible','off','Color','w','Position',[80 80 1400 850]);
end
function writeFigure(fig,out,name)
    cleanup=onCleanup(@() close(fig));
    savefig(fig,fullfile(out,string(name)+".fig"));
    exportgraphics(fig,fullfile(out,string(name)+".png"),'Resolution',300);
end
function barPlot(data,datasets,labels,colors,ytext,heading,out,name,isPercent)
    fig=newFigure(); b=bar(1:numel(datasets),data,'grouped');
    for k=1:numel(b)
        b(k).FaceColor=colors(k,:);
        text(b(k).XEndPoints,b(k).YEndPoints,compose('%.2f',b(k).YData),...
            'HorizontalAlignment','center','VerticalAlignment','bottom','FontSize',9);
    end
    xticks(1:numel(datasets)); xticklabels(datasets); ylabel(ytext); title(heading);
    legend(labels,'Location','southoutside','Orientation','horizontal'); grid on;
    if isPercent, ylim([0 105]); else, ylim([0 max(data,[],'all')*1.18+eps]); end
    writeFigure(fig,out,name);
end
