function demo_orl_lbp
% ORL / LBP+SVM 单图识别。直接运行，无需训练，不需要其他脚本。
% 从原测试集选图，重新读取图片和提取特征；真实标签仅用于事后评价。
clc;
modelFile='C:\matlab实验课\数据集\FaceProject_20260916_140101_801\experiments\LBP_SVM_20260916_152038_673\ORL\experiment.mat';
if ~isfile(modelFile)
    [file,folder]=uigetfile('*.mat','选择 LBP_SVM / ORL / experiment.mat');
    if isequal(file,0), return; end
    modelFile=fullfile(folder,file);
end
fprintf('正在加载已训练模型，请稍候……\n');
S=load(modelFile,'model','config','T','row'); % 不加载整套特征X
assert(all(isfield(S,{'model','config','T','row'})),'模型文件缺少必要变量');
assert(string(S.row.Method)=="LBP_SVM" && string(S.row.Dataset)=="ORL", ...
    '请选择 ORL 的 LBP_SVM 模型文件');
T=S.T; T.File=string(T.File); T.Label=string(T.Label); T.Split=string(T.Split);
cfg=S.config;
assert(all(isfield(cfg,{'ImageSize','CellSize','NumNeighbors','Radius'})), '特征参数不完整');
tests=T(T.Split=="test",:);
assert(~isempty(tests),'模型清单没有测试集');
assert(all(isfile(tests.File)),'测试照片路径失效，请保留原先解压数据的项目目录');
labels=strings(height(tests),1);
for k=1:height(tests)
    [~,stem,ext]=fileparts(tests.File(k));
    labels(k)=sprintf('%02d',k)+" | "+tests.Label(k)+" | "+stem+ext;
end
[index,ok]=listdlg('PromptString','选择一张测试照片，然后点确定（均未用于训练）', ...
    'ListString',cellstr(labels),'SelectionMode','single','ListSize',[460 380], ...
    'Name','选择测试照片');
if ~ok, return; end
query=tests.File(index);
% 严格沿用run_lbp_svm.m中的预处理和LBP参数。
[I,map]=imread(query);
if ~isempty(map), I=ind2rgb(I,map); end
if size(I,3)==3, I=rgb2gray(I); end
I=imresize(im2single(I),cfg.ImageSize);
x=single(extractLBPFeatures(I,'CellSize',cfg.CellSize, ...
    'NumNeighbors',cfg.NumNeighbors,'Radius',cfg.Radius, ...
    'Upright',true,'Interpolation','Linear','Normalization','L2'));
prediction=string(predict(S.model,x));
prediction=string(predict(S.model,x));
truth=tests.Label(index); correct=prediction==truth;
% 固定取预测身份的第一张训练图，仅用于对照，不参与本次预测。
refs=sortrows(T(T.Split=="train" & T.Label==prediction,:), 'File');
assert(~isempty(refs),'预测身份没有训练参考照片');
reference=refs.File(1);
assert(isfile(reference),'参考照片路径失效：%s',reference);
if correct
    result="识别正确"; color=[0 .45 .15];
else
    result="识别错误"; color=[.8 .1 .1];
end
fig=figure('Color','w','Name','ORL 单张图片识别','NumberTitle','off', ...
    'Position',[100 100 1050 580]);
tiledlayout(fig,1,2,'TileSpacing','compact','Padding','compact');
nexttile; imshow(query);
title({'输入：未参与训练的测试照片',char("真实编号："+truth)},'Interpreter','none');
nexttile; imshow(reference);
title({'预测人物的训练参考照片',char("预测编号："+prediction)},'Interpreter','none');
sgtitle("ORL / LBP + SVM — "+result,'Color',color,'FontWeight','bold','Interpreter','none');
fprintf('\n输入照片：%s\n真实身份：%s\n预测身份：%s\n结果：%s\n',query,truth,prediction,result);
% 在原模型文件旁新建演示子目录，每次单独保存。
out=fullfile(fileparts(modelFile),'single_image_demos', ...
    char(datetime('now','Format','yyyyMMdd_HHmmss_SSS')));
mkdir(out);
R=table(query,truth,prediction,correct,reference,string(modelFile), ...
    'VariableNames',{'InputFile','TrueIdentity','PredictedIdentity','Correct','ReferenceFile','ModelFile'});
writetable(R,fullfile(out,'prediction.csv'));
savefig(fig,fullfile(out,'recognition.fig'));
exportgraphics(fig,fullfile(out,'recognition.png'),'Resolution',300);
fprintf('结果图和预测记录已保存：\n%s\n',out);
fprintf('再运行 demo_orl_lbp 可选择另一张照片。\n');
fprintf('本演示识别ORL已知身份；参考照片不是检索结果，也不代表陌生人识别能力。\n');
end
