function demo_five_methods
% R2025b：从5种方法中单选或多选，对同一张测试图片重新推理。
% 不训练。真实标签仅用于评价；参考图是预测身份的第一张训练图。
clc;
start='C:\matlab实验课\数据集\FaceProject_20260916_140101_801\summaries\Comparison_20260921_093310_055';
if ~isfolder(start), start=pwd; end
folder=uigetdir(start,'选择含 selected_runs.csv 的 Comparison 文件夹');
if isequal(folder,0), return; end
assert(isfile(fullfile(folder,'selected_runs.csv')), ...
    '请选择含selected_runs.csv的Comparison文件夹，不是experiments或TSNE文件夹');
runs=readCSV(fullfile(folder,'selected_runs.csv'));
assert(all(ismember({'Method','SourceRun'},runs.Properties.VariableNames)),'实验清单列名不正确');
methods=["HOG_SVM","LBP_SVM","AlexNet","ResNet50","MobileNetV2"];
labels=["HOG + SVM","LBP + SVM","AlexNet","ResNet50","MobileNetV2"];
names=["ORL","GeorgiaTech","ExtendedYaleB"];
[d,ok]=listdlg('ListString',cellstr(names),'SelectionMode','single', ...
    'PromptString','选择数据集','Name','数据集选择','ListSize',[300 180]);
if ~ok, return; end
dataset=names(d);
[selection,ok]=listdlg('ListString',cellstr(labels),'SelectionMode','multiple', ...
    'InitialValue',1,'PromptString', ...
    {'选择识别方法：可以只选一种','按住 Ctrl 点击可以多选；点击全选可比较全部方法'}, ...
    'Name','选择方法','ListSize',[420 230]);
if ~ok || isempty(selection), return; end
methods=methods(selection); labels=labels(selection);
nMethods=numel(methods);
roots=strings(nMethods,1); models=strings(nMethods,1);
for m=1:nMethods
    idx=find(strip(string(runs.Method))==methods(m));
    assert(numel(idx)==1,'缺少或重复方法：%s',methods(m));
    roots(m)=fullfile(strip(string(runs.SourceRun(idx))),dataset);
    if ismember(methods(m),["HOG_SVM","LBP_SVM"]), name='experiment.mat'; else, name='trained_model.mat'; end
    models(m)=fullfile(roots(m),name);
    assert(isfile(models(m)),'模型文件不存在：%s',models(m));
    Q=normalizeT(readCSV(fullfile(roots(m),'split_used.csv')));
    if m==1, T=Q; else, assert(isequal(T,Q),'所选方法的划分不一致'); end
end
tests=T(T.Split=="test",:);
assert(~isempty(tests),'没有测试图片');
items=strings(height(tests),1);
for k=1:height(tests)
    [~,stem,ext]=fileparts(tests.File(k));
    items(k)=sprintf('%03d',k)+" | "+tests.Label(k)+" | "+stem+ext;
end
[k,ok]=listdlg('ListString',cellstr(items),'SelectionMode','single', ...
    'PromptString','选择一张测试照片，交给所选方法识别','Name','测试图片', ...
    'ListSize',[500 400]);
if ~ok, return; end
query=tests.File(k); truth=tests.Label(k);
assert(isfile(query),'照片路径失效，请保留原来的解压目录：%s',query);
environment='cpu';
if exist('gpuDeviceCount','file') && gpuDeviceCount('available')>0
    environment='gpu';
end
out=fullfile(folder,['SingleImage_' char(datetime('now','Format','yyyyMMdd_HHmmss_SSS'))]);
mkdir(out); diary(fullfile(out,'run_log.txt')); guard=onCleanup(@() diary('off'));
fprintf('数据集：%s\n输入照片：%s\n',dataset,query);
R=table(); refs=strings(nMethods,1); predicted=strings(nMethods,1);
for m=1:nMethods
    fprintf('\n[%d/%d] 加载 %s 并识别……\n',m,nMethods,labels(m));
    if ismember(methods(m),["HOG_SVM","LBP_SVM"])
        S=load(models(m),'model','config','T');
        assert(isequal(normalizeT(S.T),T),'模型内部划分与实验清单不符');
        cfg=S.config;
        [I,map]=imread(query);
        if ~isempty(map), I=ind2rgb(I,map); end
        if size(I,3)==3, I=rgb2gray(I); end
        I=imresize(im2single(I),cfg.ImageSize);
        if methods(m)=="HOG_SVM"
            x=extractHOGFeatures(I,'CellSize',cfg.CellSize);
        else
            x=extractLBPFeatures(I,'CellSize',cfg.CellSize, ...
                'NumNeighbors',cfg.NumNeighbors,'Radius',cfg.Radius, ...
                'Upright',true,'Interpolation','Linear','Normalization','L2');
        end
        predicted(m)=string(predict(S.model,single(x)));
    else
        S=load(models(m),'net','inputSize','classNames','T');
        assert(isequal(normalizeT(S.T),T),'网络内部划分与实验清单不符');
        % 标签不传给网络；类别顺序使用训练时保存的classNames。
        imds=imageDatastore(cellstr(query),'ReadFcn',@readRGB);
        ds=augmentedImageDatastore(S.inputSize(1:2),imds);
        scores=minibatchpredict(S.net,ds,'MiniBatchSize',1, ...
            'ExecutionEnvironment',environment,'OutputDataFormats','BC');
        if isa(scores,'dlarray'), scores=extractdata(scores); end
        scores=gather(scores);
        assert(size(scores,1)==1 && size(scores,2)==numel(S.classNames), ...
            '网络输出尺寸与保存的类别数不一致');
        assert(all(isfinite(scores),'all'),'网络输出包含非有限值');
        [~,idx]=max(scores,[],2);
        predicted(m)=string(S.classNames(idx));
        clear ds imds scores
    end
    clear S
    candidates=T(T.Split=="train" & T.Label==predicted(m),:);
    assert(~isempty(candidates),'预测身份没有训练参考图');
    refs(m)=candidates.File(1); % T已按路径排序，固定选第一张，不按相似度挑图。
    assert(isfile(refs(m)),'训练参考图路径失效：%s',refs(m));
    correct=predicted(m)==truth;
    one=table(dataset,methods(m),query,truth,predicted(m),correct,refs(m),models(m), ...
        'VariableNames',{'Dataset','Method','InputFile','TrueIdentity', ...
        'PredictedIdentity','Correct','ReferenceFile','ModelFile'});
    R=[R;one]; %#ok<AGROW>
    writetable(R,fullfile(out,'predictions.csv')); % 每种方法完成后立即保存
    fprintf('真实编号：%s；预测编号：%s；是否正确：%d\n',truth,predicted(m),correct);
end
fig=figure('Color','w','Name','同一张照片：所选方法识别结果', ...
    'NumberTitle','off','Position',[50 50 1250 850]);
nCols=min(3,nMethods+1); nRows=ceil((nMethods+1)/nCols);
if nRows==1, fig.Position=[100 100 1050 570]; end
tiledlayout(fig,nRows,nCols,'TileSpacing','compact','Padding','compact');
nexttile; imshow(query);
title({'输入：测试照片',char("真实编号："+truth)},'Interpreter','none');
for m=1:nMethods
    nexttile; imshow(refs(m));
    if R.Correct(m), verdict="正确"; color=[0 .45 .15];
    else, verdict="错误"; color=[.8 .1 .1]; end
    title({char(labels(m)+" | "+verdict), ...
        char("预测："+predicted(m)+"（训练参考图）")}, ...
        'Color',color,'Interpreter','none');
end
sgtitle(dataset+"：同一张测试照片 | "+strjoin(labels," / "),'Interpreter','none','FontWeight','bold');
savefig(fig,fullfile(out,'selected_methods_comparison.fig'));
exportgraphics(fig,fullfile(out,'selected_methods_comparison.png'),'Resolution',300);
fid=fopen(fullfile(out,'README.txt'),'w');
fprintf(fid,['One shared held-out test image, selected saved models, fresh inference, no retraining.\n' ...
    'Labels are used only for evaluation, never provided as predictors.\n' ...
    'Reference photo: first training file of the predicted identity, sorted by path.\n' ...
    'Reference images illustrate predictions; they are not retrieved nearest neighbors.\n' ...
    'Single-image demonstration is not an estimate of overall accuracy.\n' ...
    'Closed-set recognition only; no unknown-person rejection.\n']); fclose(fid);
disp(R(:,{'Method','TrueIdentity','PredictedIdentity','Correct'}));
fprintf('\n结果图与预测表已保存：\n%s\n',out);
fprintf('再次运行 demo_five_methods 可以换数据集、方法或照片。\n');
end

function T=readCSV(file)
T=readtable(file,'FileType','text','Delimiter',',','Encoding','UTF-8', ...
    'ReadVariableNames',true,'NumHeaderLines',0, ...
    'VariableNamingRule','preserve','TextType','string');
end
function T=normalizeT(T)
assert(all(ismember({'File','Label','Split'},T.Properties.VariableNames)),'缺少样本清单列');
T=T(:,{'File','Label','Split'});
T.File=string(T.File); T.Label=string(T.Label); T.Split=string(T.Split);
assert(numel(unique(T.File))==height(T),'样本路径重复');
T=sortrows(T,'File');
end
function I=readRGB(path)
[I,map]=imread(path);
if ~isempty(map), I=im2uint8(ind2rgb(I,map)); else, I=im2uint8(I); end
if size(I,3)==1, I=repmat(I,1,1,3); end
assert(size(I,3)==3,'图片不是灰度或RGB图');
end
