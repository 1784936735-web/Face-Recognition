%% HOG + SVM：三个数据集的独立实验与可视化（R2025b）
% 选择含 project_state.mat 和 manifests 文件夹的项目目录。
% 不解压、不改变原始数据划分。每次运行保存到独立输出目录。
% C仅由验证集选择；不合并训练与验证集重训，保持与首次基线一致。
% 单次固定划分实验，不包含重复实验或样本数量实验。
clear; clc;
project=uigetdir(pwd,'选择含 manifests 的 FaceProject_20260916_140101_801 文件夹');
if isequal(project,0), return; end
names=["ORL","GeorgiaTech","ExtendedYaleB"];
config=struct('ImageSize',[112 96],'CellSize',[8 8],...
    'CValues',[0.01 0.1 1 10],'Seed',20260916,...
    'TSNEPeople',10,'PredictionRepeats',3);
required=["extractHOGFeatures","fitcecoc","templateSVM","tsne"];
for f=required
    assert(~isempty(which(char(f))),'缺少函数 %s',f);
end
% 先检查全部清单，避免运行到后面才发现路径错误。
manifests=cell(3,1);
for d=1:3
    p=fullfile(project,'manifests',names(d)+"_split.csv");
    assert(isfile(p),'未找到 %s，请选择正确的项目目录。',p);
    T=readtable(p,'TextType','string');
    assert(all(ismember({'File','Label','Split'},T.Properties.VariableNames)),...
        '数据清单缺少必要字段');
    assert(all(isfile(T.File)),'部分图片路径失效，请保留旧FaceProject文件夹。');
    assert(numel(unique(T.File))==height(T),'清单存在重复文件路径');
    assert(all(ismember(T.Split,["train","validation","test"])), '未知划分名称');
    ids=unique(T.Label);
    for id=ids'
        for part=["train","validation","test"]
            assert(any(T.Label==id & T.Split==part),'身份%s在%s中没有样本',id,part);
        end
    end
    manifests{d}=T;
end
out=fullfile(project,'experiments',['HOG_SVM_' char(datetime('now','Format','yyyyMMdd_HHmmss_SSS'))]);
mkdir(out); diary(fullfile(out,'run_log.txt'));
cleanupLog=onCleanup(@() diary('off'));
save(fullfile(out,'config.mat'),'config','project');
fid=fopen(fullfile(out,'README.txt'),'w');
fprintf(fid,['Single fixed split; validation-only C selection.\n' ...
    'Accuracy and F1 in CSV are fractions (0 to 1).\n' ...
    'Timing: CPU wall clock. Feature time includes image read, resize and HOG.\n' ...
    'Prediction time: warmed batched classifier only; median of 3 passes.\n' ...
    'TrainSeconds: selected candidate fit time; TuningSeconds: all candidates and validation.\n' ...
    't-SNE: first 10 sorted identities, test images only, raw HOG with PCA, seed fixed.\n' ...
    'Small test sets make t-SNE exploratory; coordinate axes have no physical meaning.\n' ...
    'No duplicate-content or near-duplicate image detection in this script.\n' ...
    'Figures: PNG 300 dpi and editable FIG. No repeated-split uncertainty estimated.\n']);
fclose(fid);
summary=table();
for d=1:3
    fprintf('\n===== %s / HOG + SVM =====\n',names(d));
    dest=fullfile(out,names(d)); mkdir(dest);
    T=manifests{d}; writetable(T,fullfile(dest,'split_used.csv'));
    rng(config.Seed,'twister');
    n=height(T); train=T.Split=="train"; val=T.Split=="validation"; test=T.Split=="test";
    Y=categorical(T.Label); order=categorical(categories(Y));
    first=readHogImage(T.File(1),config.ImageSize);
    width=numel(extractHOGFeatures(first,'CellSize',config.CellSize));
    X=zeros(n,width,'single'); perImageSeconds=zeros(n,1);
    for i=1:n
        timer=tic;
        X(i,:)=extractHOGFeatures(readHogImage(T.File(i),config.ImageSize),'CellSize',config.CellSize);
        perImageSeconds(i)=toc(timer);
        if mod(i,200)==0 || i==n, fprintf('特征提取 %d/%d\n',i,n); end
    end
    values=config.CValues; acc=zeros(numel(values),1); fitSeconds=acc;
    valPredictions=strings(sum(val),numel(values)); best=-Inf; model=[]; selectedC=NaN;
    tuningTimer=tic;
    for k=1:numel(values)
        learner=templateSVM('KernelFunction','linear','Standardize',true,'BoxConstraint',values(k));
        timer=tic;
        candidate=fitcecoc(X(train,:),Y(train),'Learners',learner,'Coding','onevsone');
        fitSeconds(k)=toc(timer);
        pred=predict(candidate,X(val,:)); valPredictions(:,k)=string(pred);
        acc(k)=mean(pred==Y(val));
        fprintf('C=%g，验证准确率 %.2f%%\n',values(k),100*acc(k));
        if acc(k)>best
            best=acc(k); model=candidate; selectedC=values(k); selectedTime=fitSeconds(k);
        end
    end
    tuningSeconds=toc(tuningTimer);
    predictions=predict(model,X(test,:)); % 首次预测与计时预热
    batchTimes=zeros(config.PredictionRepeats,1);
    for k=1:config.PredictionRepeats
        timer=tic; predict(model,X(test,:)); batchTimes(k)=toc(timer);
    end
    truth=Y(test); C=confusionmat(truth,predictions,'Order',order);
    tp=diag(C); precision=tp./max(sum(C,1)',1); recall=tp./max(sum(C,2),1);
    f1=2*precision.*recall./max(precision+recall,eps);
    accuracy=mean(truth==predictions); macroF1=mean(f1);
    predictionMs=1000*median(batchTimes)/sum(test);
    row=table(names(d),"HOG_SVM",sum(train),sum(val),sum(test),selectedC,...
        best,accuracy,macroF1,selectedTime,tuningSeconds,sum(perImageSeconds),...
        1000*mean(perImageSeconds(test)),predictionMs,...
        'VariableNames',{'Dataset','Method','Train','Validation','Test','SelectedC',...
        'ValidationAccuracy','TestAccuracy','MacroF1','TrainSeconds','TuningSeconds',...
        'AllImagesFeatureSeconds','TestReadAndHOGMsPerImage','ClassifierMsPerImage'});
    summary=[summary;row]; %#ok<AGROW>
    writetable(summary,fullfile(out,'HOG_SVM_summary.csv'));
    writetable(table(values(:),acc,fitSeconds,'VariableNames',{'C','ValidationAccuracy','FitSeconds'}),fullfile(dest,'parameter_results.csv'));
    V=T(val,:);
    for k=1:numel(values), V.(sprintf('Prediction_C_%d',k))=valPredictions(:,k); end
    writetable(V,fullfile(dest,'validation_predictions.csv'));
    P=T(test,:); P.Prediction=string(predictions); P.Correct=truth==predictions;
    writetable(P,fullfile(dest,'test_predictions.csv'));
    writetable(table(string(order),precision,recall,f1,sum(C,2),...
        'VariableNames',{'Identity','Precision','Recall','F1','Support'}),fullfile(dest,'class_metrics.csv'));
    writematrix(C,fullfile(dest,'confusion_counts.csv'));
    % 在绘图之前保存模型与特征，绘图失败也不会丢失训练结果。
    save(fullfile(dest,'experiment.mat'),'model','config','T','X','C','order',...
        'row','acc','valPredictions','perImageSeconds','batchTimes','-v7.3');
    fprintf('测试准确率 %.2f%%，宏平均F1 %.4f；开始绘图。\n',100*accuracy,macroF1);
    try
        makePlots(T,X,P,C,order,values,acc,config,names(d),dest);
    catch ME
        warning('绘图未全部完成，模型和结果已保存：%s',ME.message);
        fid=fopen(fullfile(dest,'plot_error.txt'),'w'); fprintf(fid,'%s',getReport(ME,'extended','hyperlinks','off')); fclose(fid);
    end
end
fig=newFigure(); bar(categorical(summary.Dataset),100*[summary.TestAccuracy summary.MacroF1]);
ylabel('Score (%)'); ylim([0 100]); legend('Accuracy','Macro-F1','Location','best');
title('HOG + SVM: single-split results'); grid on; writeFigure(fig,out,'all_datasets_scores');
disp(summary); fprintf('\n全部训练完成。输出目录：\n%s\n',out); diary off;

function I=readHogImage(path,target)
    [I,map]=imread(path);
    if ~isempty(map), I=ind2rgb(I,map); end
    if size(I,3)==3, I=rgb2gray(I); end
    I=imresize(im2single(I),target);
end
function fig=newFigure()
    fig=figure('Visible','off','Color','w','Position',[100 100 1100 750]);
end
function writeFigure(fig,out,name)
    c=onCleanup(@() close(fig));
    savefig(fig,fullfile(out,name+".fig"));
    exportgraphics(fig,fullfile(out,name+".png"),'Resolution',300);
end
function makePlots(T,X,P,C,order,values,acc,cfg,name,out)
    ids=unique(T.Label);
    % 1. 数据样例
    fig=newFigure(); tiledlayout(3,4,'TileSpacing','compact');
    for k=1:min(12,numel(ids))
        idx=find(T.Label==ids(k),1); nexttile; imshow(T.File(idx)); title(ids(k),'Interpreter','none');
    end
    sgtitle(name+" - identity examples"); writeFigure(fig,out,'01_samples');
    % 2. 每人样本分布
    counts=zeros(numel(ids),3); splits=["train","validation","test"];
    for k=1:numel(ids)
        for j=1:3, counts(k,j)=sum(T.Label==ids(k) & T.Split==splits(j)); end
    end
    fig=newFigure(); bar(counts,'stacked'); xticks(1:numel(ids)); xticklabels(ids); xtickangle(90);
    ylabel('Images'); xlabel('Identity'); legend(splits,'Location','best'); title(name+" - saved split");
    writeFigure(fig,out,'02_sample_counts');
    % 3. 原图、预处理和HOG
    fig=newFigure(); tiledlayout(3,3,'TileSpacing','compact');
    for k=1:3
        idx=find(T.Label==ids(k) & T.Split=="train",1);
        I=readHogImage(T.File(idx),cfg.ImageSize);
        [~,vis]=extractHOGFeatures(I,'CellSize',cfg.CellSize);
        nexttile; imshow(T.File(idx)); title("Original: "+ids(k));
        nexttile; imshow(I); title('Grayscale + resize');
        nexttile; imshow(I); hold on; plot(vis); title('HOG visualization');
    end
    writeFigure(fig,out,'03_preprocessing_hog');
    % 4. 参数曲线：横轴采用对数刻度，禁止使用测试集选C。
    fig=newFigure(); semilogx(values,100*acc,'-o','LineWidth',2,'MarkerSize',8);
    xticks(values); grid on; xlabel('SVM C (log scale)'); ylabel('Validation accuracy (%)');
    title(name+" - validation-only parameter selection"); ylim([0 100]);
    writeFigure(fig,out,'04_parameter_curve');
    % 5-6. 原始计数与按真实类别归一化混淆矩阵
    fig=newFigure(); confusionchart(C,string(order),'Title',char(name+" - test counts"));
    writeFigure(fig,out,'05_confusion_counts');
    fig=newFigure(); confusionchart(C,string(order),'Normalization','row-normalized',...
        'Title',char(name+" - row-normalized test confusion"));
    writeFigure(fig,out,'06_confusion_normalized');
    % 7-8. 固定顺序展示案例，不挑选最好看的结果。
    for flag=[true false]
        rows=find(P.Correct==flag); fig=newFigure(); tiledlayout(3,4,'TileSpacing','compact');
        if isempty(rows)
            nexttile; axis off; text(0,0.5,'No cases in this category');
        else
            for k=1:min(12,numel(rows))
                r=rows(k); nexttile; imshow(P.File(r));
                title("True: "+P.Label(r)+" | Pred: "+P.Prediction(r),'Interpreter','none','FontSize',9);
            end
        end
        if flag, label="07_correct_cases"; else, label="08_error_cases"; end
        sgtitle(name+" - "+replace(label,'_',' ')); writeFigure(fig,out,label);
    end
    % 9. 同一组测试身份和文件：后续方法复用此选择规则。
    selectedIds=ids(1:min(cfg.TSNEPeople,numel(ids)));
    rows=find(T.Split=="test" & ismember(T.Label,selectedIds));
    Z=double(X(rows,:)); Z=Z(:,std(Z,0,1)>0);
    rng(cfg.Seed,'twister'); perplexity=min(30,max(2,floor((numel(rows)-1)/3)));
    components=min([50,size(Z,2),size(Z,1)-1]);
    embedding=tsne(Z,'Algorithm','exact','NumPCAComponents',components,...
        'Perplexity',perplexity,'Standardize',false);
    S=T(rows,:); S.TSNE1=embedding(:,1); S.TSNE2=embedding(:,2);
    writetable(S,fullfile(out,'tsne_test_samples.csv'));
    save(fullfile(out,'tsne_settings.mat'),'perplexity','components','selectedIds','rows');
    fig=newFigure(); hold on; colors=lines(numel(selectedIds));
    for k=1:numel(selectedIds)
        mask=S.Label==selectedIds(k);
        scatter(embedding(mask,1),embedding(mask,2),55,colors(k,:),'filled','DisplayName',char(selectedIds(k)));
    end
    legend('Location','eastoutside'); xlabel('t-SNE 1'); ylabel('t-SNE 2'); grid on;
    title(sprintf('%s - test HOG t-SNE (%d images; exploratory)',name,numel(rows)));
    writeFigure(fig,out,'09_tsne');
end